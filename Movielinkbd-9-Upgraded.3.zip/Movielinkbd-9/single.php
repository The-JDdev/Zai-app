<?php
/**
 * MovieLinkBD single and definitions
 *
 * @package MovieLinkBD.Com
 * Author: 9xfreak.com
 * @since MovieLinkBD 1.0
 */
get_header();
global $movielinkbd;
?>

<main class="max-w-screen-lg p-1 mx-auto overflow-hidden">
	<section class="p-1 bg-white shadow-lg rounded-lg border-left-dark" style="max-width: calc(100% - 10%); margin: 0 auto;">

	<?php 
	if(have_posts()): while(have_posts()):the_post();
	$Rating = get_post_meta($post->ID, 'custom-field-2', true)?: '0.0';
	$screenshots = get_post_meta($post->ID, 'custom-field-1', true)?: '0.0';
	$DownloadNotice = get_post_meta($post->ID, 'custom-field-34', true);
	
	// Original buttons - NO DEFAULT TEXT
	$ButtonOne = get_post_meta($post->ID, 'custom-field-3', true);
	$ButtonTwo = get_post_meta($post->ID, 'custom-field-6', true);
	$ButtonThree = get_post_meta($post->ID, 'custom-field-8', true);
	$ButtonFour = get_post_meta($post->ID, 'custom-field-10', true);
	$ButtonFive = get_post_meta($post->ID, 'custom-field-12', true);
	
	$downloadOne = get_post_meta($post->ID, 'custom-field-4', true);
	$downloadTwo = get_post_meta($post->ID, 'custom-field-7', true);
	$downloadThree = get_post_meta($post->ID, 'custom-field-9', true);
	$downloadFour = get_post_meta($post->ID, 'custom-field-11', true);
	$downloadFive = get_post_meta($post->ID, 'custom-field-13', true);
	
	// New fields
	$watch_online_url = get_post_meta($post->ID, 'watch_online_url', true);
	$is_episode = get_post_meta($post->ID, 'is_episode', true);
	$episode_range = get_post_meta($post->ID, 'episode_range', true);
	$pinned_badge = get_post_meta($post->ID, 'pinned_badge', true);
	$new_badge = get_post_meta($post->ID, 'new_badge', true);
	$yes_no_toggle = get_post_meta($post->ID, 'yes_no_toggle', true);
	$adult_yes_no_toggle = get_post_meta($post->ID, 'adult_yes_no_toggle', true);
	
	// Additional buttons for each main button
	$additional_buttons_1 = get_post_meta($post->ID, 'additional_buttons_1', true) ?: array();
	$additional_buttons_2 = get_post_meta($post->ID, 'additional_buttons_2', true) ?: array();
	$additional_buttons_3 = get_post_meta($post->ID, 'additional_buttons_3', true) ?: array();
	$additional_buttons_4 = get_post_meta($post->ID, 'additional_buttons_4', true) ?: array();
	$additional_buttons_5 = get_post_meta($post->ID, 'additional_buttons_5', true) ?: array();
	
	// Episode sections
	$episode_sections = get_post_meta($post->ID, '_episode_sections', true);
	if (empty($episode_sections)) $episode_sections = array();
	
	// Time ago calculation
	$post_time = get_the_time('U');
	$current_time = current_time('U');
	$time_difference = human_time_diff($post_time, $current_time);
	
	// Notice sections
	$notice_sections = get_post_meta($post->ID, '_notice_sections', true);
	if (empty($notice_sections)) $notice_sections = array();
	?>

	<?php if ($adult_yes_no_toggle === '1'): ?>
<div style="position:absolute;top:10px;right:10px;z-index:10;"><span style="padding:5px 12px;border-radius:6px;font-size:11px;font-weight:700;color:#fff;background:linear-gradient(135deg,#dc2626,#7e22ce);">🔞 18+ Adult</span></div>
<?php endif; ?>

<!-- Featured Image Start -->
	<div class="movie-cards-container-view">

	<div class="movie-card-view shadow-sm">
        <div class="image-container-view">
            <?php
		$thumbnail = get_template_directory_uri()."/images/no-image.png";
		if ( has_post_thumbnail() ) {
		the_post_thumbnail('featured-image',array("alt" => get_the_title(),"loading" => "b-lazy","class" => "b-loaded"));
		} else {
		echo '<img src="'.$thumbnail.'"'.' alt="'.get_the_title().'"'.' loading="b-lazy"'.' class="b-loaded"/>';
		} ?>
		
		<!-- Top left badges: Rating, Pinned, New in a row -->
		<div class="badges-row" style="position: absolute; top: 10px; left: 10px; display: flex; align-items: center; gap: 5px; z-index: 2;">
			<?php
			echo '<span class="rating-badge">'.$Rating.'</span>';
			
			if ($pinned_badge === '1') {
				echo '<span class="pinned-badge">Pinned</span>';
			}
			if ($new_badge === '1') {
				echo '<span class="new-badge">New</span>';
			}
			?>
		</div>

		<!-- Original right side badges -->
		<?php 
		echo'<span class="quality">';
		echo strip_tags(get_the_term_list( $post->ID, 'quality', ' ',', '));
		echo '</span>';
		?>
                
		<?php 
		echo'<span class="language">';
		echo strip_tags(get_the_term_list( $post->ID, 'language', ' ',', '));
		echo '</span>';
		?>

		<?php 
		echo'<span class="type">';
		echo strip_tags(get_the_term_list( $post->ID, 'movie-type', ' ',', '));
		echo '</span>';
		?>
	</div>
	</div>

	<div class="movie-card-view">
        <h2 class="mb-2 text-lg font-bold" style="word-wrap: break-word; display: flex; align-items: center; gap: 10px;">
		<?php the_title(); ?>
		<button id="copy-url-btn" class="copy-url-btn" style="background: #007cba; color: white; border: none; padding: 5px 10px; border-radius: 3px; cursor: pointer; font-size: 12px;" title="Copy URL">
			Copy URL
		</button>
	</h2>
		
		<!-- Only show Type, Language, Quality - Remove unwanted text -->
		<?php 
		echo'<p>'.'Type : '.'<b class="text-orange uppercase">';
		echo strip_tags(get_the_term_list( $post->ID, 'movie-type', ' ',', '));
		echo '</b></p>';
		?>
		<?php 
		echo'<p>'.'Language / ভাষা : '.'<b class="text-orange uppercase">';
		echo strip_tags(get_the_term_list( $post->ID, 'language', ' ',', '));
		echo '</b></p>';
		?>
		<?php 
		echo'<p>'.'QuaLity : '.'<b class="text-orange uppercase">';
		echo strip_tags(get_the_term_list( $post->ID, 'quality', ' ',', '));
		echo '</b></p>';
		?>
	</div>

	</div>
	<!-- Featured Image End -->

<?php if($screenshots >0){
echo'<div class="text-md border-bottom-danger text-center align-items-center text-warning font-weight-bold text-uppercase" style="user-select: none">
	<br/>
	<h3 class="text-md text-danger"> Screenshots </h3>
</div>
<br/>
<center class="screenshot"><img src="';
echo $screenshots;
echo'" loading="b-lazy" alt="" title="" class="responsive-img mb-2 b-loaded"/></center>';}
?>

<!-- Posted Time and Episode Info in same line with small text -->
<div class="post-time-episode-container" style="margin: 15px 0; text-align: center; font-size: 12px;">
	<!-- Posted Time -->
	<span class="posted-time" style="margin: 0 10px;">
		<i class="fas fa-clock" style="margin-right: 3px; color: #007cba;"></i>
		<strong style="color: #333;">Posted: <?php echo $time_difference; ?> ago</strong>
	</span>
	
	<!-- Episode Info (only if episode) -->
	<?php if ($is_episode === '1' && !empty($episode_range)): ?>
	<span class="episode-info" style="margin: 0 10px;">
		<i class="fas fa-play-circle" style="margin-right: 3px; color: #007cba;"></i>
		<strong style="color: #333;"> <?php echo esc_html($episode_range); ?></strong>
	</span>
	<?php endif; ?>
</div>

<!-- Main Watch Online Button (For All Posts) -->
<?php if (!empty($watch_online_url)): ?>
<div class="text-md border-bottom-dark mb-4 text-center align-items-center text-warning font-weight-bold text-uppercase" style="user-select: none">
	<br/>
	<h3 class="text-md text-primary"> WATCH ONLINE </h3>
</div>

<div class="container mt-4 mb-4 shadow-rounded shadow-lg rounded-lg border-left-primary">
    <div class="row">
        <div class="col-12 p-4 text-center">
            <a href="javascript:void(0)" onclick="showAdAndRedirect('<?php echo esc_url($watch_online_url); ?>')" class="btn btn-primary btn-user" style="background: #007cba; color: white; padding: 6px 16px; font-size: 13px; font-weight: bold;">
                <b class="btn-text"> 
                    <i class="fas fa-play-circle"></i> 
                    Watch Online 
                    <i class="fas fa-play-circle"></i> 
                </b>
            </a>
        </div>
    </div>
</div>
<?php endif; ?>

<div class="text-md border-bottom-dark mb-4 text-center align-items-center text-warning font-weight-bold text-uppercase" style="user-select: none">
	<br/>
	<div class="tax-container" style="display:flex;flex-wrap:wrap;gap:8px;padding:15px;background:#1a1b23;border-radius:10px;margin:10px 0;border:1px solid #2a2b35;"><?php $genres=get_the_terms(get_the_ID(),"genres"); $langs=get_the_terms(get_the_ID(),"languages"); $types=get_the_terms(get_the_ID(),"types"); $quals=get_the_terms(get_the_ID(),"quality"); if($genres&&!is_wp_error($genres)){echo "<div style="background:#22232e;padding:6px 14px;border-radius:6px;font-size:13px;color:#f8f9fc;border:1px solid #2a2b35;"><i class="fas fa-folder-open"></i> ";$n=array();foreach($genres as $t){$n[]=$t->name;}echo implode(", ",$n)."</div>";} if($langs&&!is_wp_error($langs)){echo "<div style="background:#22232e;padding:6px 14px;border-radius:6px;font-size:13px;color:#f8f9fc;border:1px solid #2a2b35;"><i class="fas fa-language"></i> ";$n=array();foreach($langs as $t){$n[]=$t->name;}echo implode(", ",$n)."</div>";} if($types&&!is_wp_error($types)){echo "<div style="background:#22232e;padding:6px 14px;border-radius:6px;font-size:13px;color:#f8f9fc;border:1px solid #2a2b35;"><i class="fas fa-film"></i> ";$n=array();foreach($types as $t){$n[]=$t->name;}echo implode(", ",$n)."</div>";} if($quals&&!is_wp_error($quals)){echo "<div style="background:#22232e;padding:6px 14px;border-radius:6px;font-size:13px;color:#f8f9fc;border:1px solid #2a2b35;"><i class="fas fa-tv"></i> ";$n=array();foreach($quals as $t){$n[]=$t->name;}echo implode(", ",$n)."</div>";} ?></div><div class="movie-extra-info" style="background:#1a1b23;border-radius:10px;padding:15px;margin:10px 0;border:1px solid #2a2b35;"><?php if($Rating&&$Rating!="0.0"){echo "<p style="display:flex;justify-content:space-between;padding:6px 0;border-bottom:1px solid #2a2b35;font-size:14px;margin:0;"><span style="color:#858796;font-weight:600;"><i class="fas fa-star"></i> Rating</span><span style="color:#f8f9fc;">⭐ ".esc_html($Rating)."/10</span></p>";} if($is_episode==="1"&&!empty($episode_range)){echo "<p style="display:flex;justify-content:space-between;padding:6px 0;border-bottom:1px solid #2a2b35;font-size:14px;margin:0;"><span style="color:#858796;font-weight:600;"><i class="fas fa-play-circle"></i> Episodes</span><span style="color:#f8f9fc;">".esc_html($episode_range)."</span></p>";} echo "<p style="display:flex;justify-content:space-between;padding:6px 0;font-size:14px;margin:0;"><span style="color:#858796;font-weight:600;"><i class="fas fa-clock"></i> Posted</span><span style="color:#f8f9fc;">".$time_difference." ago</span></p>"; ?></div><div class="vlc-notice-responsive" style="background:#1b1b1b;color:#f1f1f1;border-left:4px solid #ffc107;box-shadow:0 0 10px rgba(255,193,7,0.25);border-radius:8px;padding:20px;margin:15px 0;"><div style="margin-bottom:10px;">🔇 <span style="color:#ffc107;font-weight:700;">VLC Player Recommended</span><br>👉 <span style="color:#87CEEB;font-weight:600;">VLC Player</span> দিয়ে প্লে করুন</div><div style="text-align:center;margin-top:10px;"><a href="https://play.google.com/store/apps/details?id=org.videolan.vlc" style="background:#2563eb;color:#fff;padding:8px 16px;border-radius:6px;font-weight:600;text-decoration:none;display:inline-block;">📥 VLC Player ডাউনলোড</a></div></div><h3 class="text-md text-success"> 👇DOWNLOAD LINKS👇 </h3>
</div>

<!-- Original Notice Box -->
<?php if (!empty($DownloadNotice)) : ?>
    <div class="download-notice" style="color: yellow !important; background-color: black; padding: 15px; border-left: 5px solid yellow; font-weight: bold; border-radius: 8px; margin: 20px 0;">
        <?php echo esc_html($DownloadNotice); ?>
    </div>
<?php endif; ?>

<!-- Original Download Buttons with Additional Buttons -->
<div class="container mt-6 mb-6 shadow-rounded shadow-lg rounded-lg border-left-success">
    <div class="row">
        <div class="col-12 p-4 mt-4 text-center d-flex flex-wrap justify-content-center">
            <!-- Button 1 - ONLY SHOW IF TEXT EXISTS -->
            <?php if(!empty($ButtonOne)): ?>
                <div class="button-with-additional mb-4 mx-2">
                    <?php if(!empty($downloadOne) && $downloadOne != '0'): ?>
                        <!-- Main button with link - direct download -->
                        <a href="javascript:void(0)" onclick="showAdAndRedirect('<?php echo $downloadOne; ?>')" class="btn btn-dark btn-user main-button" style="padding: 6px 14px; font-size: 12px;">
                            <b class="btn-text"> <i class="fas fa-cloud-download-alt"></i> <?php echo $ButtonOne; ?> <i class="fas fa-cloud-download-alt"></i> </b>
                        </a>
                    <?php else: ?>
                        <!-- Main button without link - toggles additional buttons -->
                        <a href="javascript:void(0)" class="btn btn-dark btn-user main-button-toggle" data-target="additionalButtons1" style="padding: 6px 14px; font-size: 12px;">
                            <b class="btn-text"> <i class="fas fa-cloud-download-alt"></i> <?php echo $ButtonOne; ?> <i class="fas fa-cloud-download-alt"></i> </b>
                        </a>
                    <?php endif; ?>
                    
                    <!-- Additional Buttons for Button 1 -->
                    <?php if (!empty($additional_buttons_1)): ?>
                    <div class="additional-buttons-container mt-2" id="additionalButtons1" style="display: none;">
                        <div class="d-flex flex-wrap justify-content-center gap-2">
                            <?php foreach ($additional_buttons_1 as $index => $button): ?>
                                <?php if (!empty($button['text']) && !empty($button['url'])): ?>
                                <a href="javascript:void(0)" onclick="showAdAndRedirect('<?php echo esc_url($button['url']); ?>')" class="btn btn-outline-dark additional-button" style="padding: 5px 10px; font-size: 11px; font-weight: bold; margin: 5px;">
                                    <b class="btn-text"> 
                                        <i class="fas fa-download"></i> 
                                        <?php echo esc_html($button['text']); ?> 
                                    </b>
                                </a>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
            
            <!-- Button 2 - ONLY SHOW IF TEXT EXISTS -->
            <?php if(!empty($ButtonTwo)): ?>
                <div class="button-with-additional mb-4 mx-2">
                    <?php if(!empty($downloadTwo) && $downloadTwo != '0'): ?>
                        <!-- Main button with link - direct download -->
                        <a href="javascript:void(0)" onclick="showAdAndRedirect('<?php echo $downloadTwo; ?>')" class="btn btn-dark btn-user main-button" style="padding: 6px 14px; font-size: 12px;">
                            <b class="btn-text"> <i class="fas fa-cloud-download-alt"></i> <?php echo $ButtonTwo; ?> <i class="fas fa-cloud-download-alt"></i> </b>
                        </a>
                    <?php else: ?>
                        <!-- Main button without link - toggles additional buttons -->
                        <a href="javascript:void(0)" class="btn btn-dark btn-user main-button-toggle" data-target="additionalButtons2" style="padding: 6px 14px; font-size: 12px;">
                            <b class="btn-text"> <i class="fas fa-cloud-download-alt"></i> <?php echo $ButtonTwo; ?> <i class="fas fa-cloud-download-alt"></i> </b>
                        </a>
                    <?php endif; ?>
                    
                    <!-- Additional Buttons for Button 2 -->
                    <?php if (!empty($additional_buttons_2)): ?>
                    <div class="additional-buttons-container mt-2" id="additionalButtons2" style="display: none;">
                        <div class="d-flex flex-wrap justify-content-center gap-2">
                            <?php foreach ($additional_buttons_2 as $index => $button): ?>
                                <?php if (!empty($button['text']) && !empty($button['url'])): ?>
                                <a href="javascript:void(0)" onclick="showAdAndRedirect('<?php echo esc_url($button['url']); ?>')" class="btn btn-outline-dark additional-button" style="padding: 5px 10px; font-size: 11px; font-weight: bold; margin: 5px;">
                                    <b class="btn-text"> 
                                        <i class="fas fa-download"></i> 
                                        <?php echo esc_html($button['text']); ?> 
                                    </b>
                                </a>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
            
            <!-- Button 3 - ONLY SHOW IF TEXT EXISTS -->
            <?php if(!empty($ButtonThree)): ?>
                <div class="button-with-additional mb-4 mx-2">
                    <?php if(!empty($downloadThree) && $downloadThree != '0'): ?>
                        <!-- Main button with link - direct download -->
                        <a href="javascript:void(0)" onclick="showAdAndRedirect('<?php echo $downloadThree; ?>')" class="btn btn-dark btn-user main-button" style="padding: 6px 14px; font-size: 12px;">
                            <b class="btn-text"> <i class="fas fa-cloud-download-alt"></i> <?php echo $ButtonThree; ?> <i class="fas fa-cloud-download-alt"></i> </b>
                        </a>
                    <?php else: ?>
                        <!-- Main button without link - toggles additional buttons -->
                        <a href="javascript:void(0)" class="btn btn-dark btn-user main-button-toggle" data-target="additionalButtons3" style="padding: 6px 14px; font-size: 12px;">
                            <b class="btn-text"> <i class="fas fa-cloud-download-alt"></i> <?php echo $ButtonThree; ?> <i class="fas fa-cloud-download-alt"></i> </b>
                        </a>
                    <?php endif; ?>
                    
                    <!-- Additional Buttons for Button 3 -->
                    <?php if (!empty($additional_buttons_3)): ?>
                    <div class="additional-buttons-container mt-2" id="additionalButtons3" style="display: none;">
                        <div class="d-flex flex-wrap justify-content-center gap-2">
                            <?php foreach ($additional_buttons_3 as $index => $button): ?>
                                <?php if (!empty($button['text']) && !empty($button['url'])): ?>
                                <a href="javascript:void(0)" onclick="showAdAndRedirect('<?php echo esc_url($button['url']); ?>')" class="btn btn-outline-dark additional-button" style="padding: 5px 10px; font-size: 11px; font-weight: bold; margin: 5px;">
                                    <b class="btn-text"> 
                                        <i class="fas fa-download"></i> 
                                        <?php echo esc_html($button['text']); ?> 
                                    </b>
                                </a>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
            
            <!-- Button 4 - ONLY SHOW IF TEXT EXISTS -->
            <?php if(!empty($ButtonFour)): ?>
                <div class="button-with-additional mb-4 mx-2">
                    <?php if(!empty($downloadFour) && $downloadFour != '0'): ?>
                        <!-- Main button with link - direct download -->
                        <a href="javascript:void(0)" onclick="showAdAndRedirect('<?php echo $downloadFour; ?>')" class="btn btn-dark btn-user main-button" style="padding: 6px 14px; font-size: 12px;">
                            <b class="btn-text"> <i class="fas fa-cloud-download-alt"></i> <?php echo $ButtonFour; ?> <i class="fas fa-cloud-download-alt"></i> </b>
                        </a>
                    <?php else: ?>
                        <!-- Main button without link - toggles additional buttons -->
                        <a href="javascript:void(0)" class="btn btn-dark btn-user main-button-toggle" data-target="additionalButtons4" style="padding: 6px 14px; font-size: 12px;">
                            <b class="btn-text"> <i class="fas fa-cloud-download-alt"></i> <?php echo $ButtonFour; ?> <i class="fas fa-cloud-download-alt"></i> </b>
                        </a>
                    <?php endif; ?>
                    
                    <!-- Additional Buttons for Button 4 -->
                    <?php if (!empty($additional_buttons_4)): ?>
                    <div class="additional-buttons-container mt-2" id="additionalButtons4" style="display: none;">
                        <div class="d-flex flex-wrap justify-content-center gap-2">
                            <?php foreach ($additional_buttons_4 as $index => $button): ?>
                                <?php if (!empty($button['text']) && !empty($button['url'])): ?>
                                <a href="javascript:void(0)" onclick="showAdAndRedirect('<?php echo esc_url($button['url']); ?>')" class="btn btn-outline-dark additional-button" style="padding: 5px 10px; font-size: 11px; font-weight: bold; margin: 5px;">
                                    <b class="btn-text"> 
                                        <i class="fas fa-download"></i> 
                                        <?php echo esc_html($button['text']); ?> 
                                    </b>
                                </a>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
            
            <!-- Button 5 - ONLY SHOW IF TEXT EXISTS -->
            <?php if(!empty($ButtonFive)): ?>
                <div class="button-with-additional mb-4 mx-2">
                    <?php if(!empty($downloadFive) && $downloadFive != '0'): ?>
                        <!-- Main button with link - direct download -->
                        <a href="javascript:void(0)" onclick="showAdAndRedirect('<?php echo $downloadFive; ?>')" class="btn btn-dark btn-user main-button" style="padding: 6px 14px; font-size: 12px;">
                            <b class="btn-text"> <i class="fas fa-cloud-download-alt"></i> <?php echo $ButtonFive; ?> <i class="fas fa-cloud-download-alt"></i> </b>
                        </a>
                    <?php else: ?>
                        <!-- Main button without link - toggles additional buttons -->
                        <a href="javascript:void(0)" class="btn btn-dark btn-user main-button-toggle" data-target="additionalButtons5" style="padding: 6px 14px; font-size: 12px;">
                            <b class="btn-text"> <i class="fas fa-cloud-download-alt"></i> <?php echo $ButtonFive; ?> <i class="fas fa-cloud-download-alt"></i> </b>
                        </a>
                    <?php endif; ?>
                    
                    <!-- Additional Buttons for Button 5 -->
                    <?php if (!empty($additional_buttons_5)): ?>
                    <div class="additional-buttons-container mt-2" id="additionalButtons5" style="display: none;">
                        <div class="d-flex flex-wrap justify-content-center gap-2">
                            <?php foreach ($additional_buttons_5 as $index => $button): ?>
                                <?php if (!empty($button['text']) && !empty($button['url'])): ?>
                                <a href="javascript:void(0)" onclick="showAdAndRedirect('<?php echo esc_url($button['url']); ?>')" class="btn btn-outline-dark additional-button" style="padding: 5px 10px; font-size: 11px; font-weight: bold; margin: 5px;">
                                    <b class="btn-text"> 
                                        <i class="fas fa-download"></i> 
                                        <?php echo esc_html($button['text']); ?> 
                                    </b>
                                </a>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Notice Sections with Additional Buttons Support -->
<?php if (!empty($notice_sections)) : ?>
    <?php foreach ($notice_sections as $section_index => $section) : ?>
        <?php if (!empty($section['notice']) && !empty($section['buttons'])) : ?>
            <!-- Notice Box -->
            <div class="download-notice" style="color: yellow !important; background-color: black; padding: 15px; border-left: 5px solid yellow; font-weight: bold; border-radius: 8px; margin: 20px 0;">
                <?php echo esc_html($section['notice']); ?>
            </div>
            
            <!-- Download Buttons for This Section -->
            <div class="container mt-6 mb-6 shadow-rounded shadow-lg rounded-lg border-left-success">
                <div class="row">
                    <div class="col-12 p-4 mt-4 text-center d-flex flex-wrap justify-content-center">
                        <?php foreach ($section['buttons'] as $button_index => $button) : ?>
                            <?php if (!empty($button['text'])) : ?>
                                <div class="button-with-additional mb-4 mx-2">
                                    <?php if (!empty($button['url'])) : ?>
                                        <!-- Main button with link - direct download -->
                                        <a href="javascript:void(0)" onclick="showAdAndRedirect('<?php echo esc_url($button['url']); ?>')" class="btn btn-dark btn-user main-button" style="padding: 6px 14px; font-size: 12px;">
                                            <b class="btn-text"> 
                                                <i class="fas fa-cloud-download-alt"></i> 
                                                <?php echo esc_html($button['text']); ?> 
                                                <i class="fas fa-cloud-download-alt"></i> 
                                            </b>
                                        </a>
                                    <?php else: ?>
                                        <!-- Main button without link - toggles additional buttons -->
                                        <a href="javascript:void(0)" class="btn btn-dark btn-user main-button-toggle" data-target="noticeAdditionalButtons<?php echo $section_index . '_' . $button_index; ?>" style="padding: 6px 14px; font-size: 12px;">
                                            <b class="btn-text"> 
                                                <i class="fas fa-cloud-download-alt"></i> 
                                                <?php echo esc_html($button['text']); ?> 
                                                <i class="fas fa-cloud-download-alt"></i> 
                                            </b>
                                        </a>
                                    <?php endif; ?>
                                    
                                    <!-- Additional Buttons for Notice Section Buttons -->
                                    <?php 
                                    $notice_additional_buttons = isset($button['additional_buttons']) ? $button['additional_buttons'] : array();
                                    if (!empty($notice_additional_buttons)): 
                                    ?>
                                    <div class="additional-buttons-container mt-2" id="noticeAdditionalButtons<?php echo $section_index . '_' . $button_index; ?>" style="display: none;">
                                        <div class="d-flex flex-wrap justify-content-center gap-2">
                                            <?php foreach ($notice_additional_buttons as $add_index => $add_button) : ?>
                                                <?php if (!empty($add_button['text']) && !empty($add_button['url'])) : ?>
                                                <a href="javascript:void(0)" onclick="showAdAndRedirect('<?php echo esc_url($add_button['url']); ?>')" class="btn btn-outline-dark additional-button" style="padding: 5px 10px; font-size: 11px; font-weight: bold; margin: 5px;">
                                                    <b class="btn-text"> 
                                                        <i class="fas fa-download"></i> 
                                                        <?php echo esc_html($add_button['text']); ?> 
                                                    </b>
                                                </a>
                                                <?php endif; ?>
                                            <?php endforeach; ?>
                                        </div>
                                    </div>
                                    <?php endif; ?>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    <?php endforeach; ?>
<?php endif; ?>

<!-- Episode Sections (After Main Download and Notice Sections) -->
<?php if ($is_episode === '1' && !empty($episode_sections)): ?>
    <!-- Main Episode Heading (Only for first section) -->
    <?php if (count($episode_sections) > 0): ?>
    <div class="text-md mb-4 text-center align-items-center text-warning font-weight-bold text-uppercase" style="user-select: none; border-bottom: none !important;">
        <h3 class="text-md text-primary" style="font-size: 18px; margin-bottom: 5px;">Episodes Wise Download</h3>
        <p style="font-size: 14px; color: #666; margin: 0;">Download Your Favorite Episodes</p>
    </div>
    <?php endif; ?>

    <?php foreach ($episode_sections as $section_index => $section): ?>
        <?php 
        $has_watch_online = !empty($section['watch_online_url']);
        $has_download_buttons = !empty($section['buttons']);
        
        // Only show section if it has either watch online or download buttons
        if ($has_watch_online || $has_download_buttons):
        ?>
        <div class="episode-section" style="border: 2px solid #4ecdc4; border-radius: 8px; padding: 20px; margin: 20px 0; text-align: center; position: relative;">
            
            <!-- Episode Badge - Top Right (Only if selected) -->
            <?php if ($section['badge'] === '1'): ?>
            <div class="episode-badge" style="position: absolute; top: 10px; right: 10px; background: #4ecdc4; color: white; padding: 4px 8px; border-radius: 4px; font-size: 10px; font-weight: bold;">
                New Added
            </div>
            <?php endif; ?>
            
            <!-- Episode Title in bordered box without background -->
            <?php if (!empty($section['episode_number'])): ?>
            <div class="episode-title-box" style="margin-bottom: 15px; border: 1px solid #4ecdc4; padding: 8px; border-radius: 4px; background: transparent;">
                <h4 style="font-size: 16px; font-weight: bold; color: #333; margin: 0; text-align: center;">
                    <?php echo esc_html($section['episode_number']); ?>
                </h4>
            </div>
            <?php endif; ?>

            <!-- Optional Subtitle without border -->
            <?php if (!empty($section['episode_subtitle'])): ?>
            <div class="episode-subtitle" style="margin-bottom: 15px;">
                <p style="font-size: 14px; color: #666; margin: 5px 0 0 0; text-align: center;">
                    <?php echo esc_html($section['episode_subtitle']); ?>
                </p>
            </div>
            <?php endif; ?>

            <!-- Episode Watch Online Button (Separate Line, Same Blue as Main) -->
            <?php if ($has_watch_online): ?>
            <div class="episode-watch-online" style="margin-bottom: 15px;">
                <a href="javascript:void(0)" onclick="showAdAndRedirect('<?php echo esc_url($section['watch_online_url']); ?>')" class="btn btn-primary btn-user" style="background: #007cba; color: white; padding: 6px 16px; font-size: 13px; font-weight: bold;">
                    <b class="btn-text"> 
                        <i class="fas fa-play-circle"></i> 
                        Watch Online 
                        <i class="fas fa-play-circle"></i> 
                    </b>
                </a>
            </div>
            <?php endif; ?>

            <!-- Episode Download Buttons with Individual Subtitle and Watch Online -->
            <?php if ($has_download_buttons): ?>
            <div class="episode-download-buttons">
                <div class="d-flex flex-wrap justify-content-center gap-2">
                    <?php foreach ($section['buttons'] as $button_index => $button): ?>
                        <?php if (!empty($button['text'])): ?>
                            <div class="button-with-additional mb-2">
                                
                                <!-- NEW: Button-specific Subtitle -->
                                <?php if (!empty($button['button_subtitle'])): ?>
                                <div class="episode-button-subtitle" style="margin-bottom: 10px;">
                                    <p style="font-size: 14px; color: #666; margin: 0; text-align: center; font-style: italic;">
                                        <?php echo esc_html($button['button_subtitle']); ?>
                                    </p>
                                </div>
                                <?php endif; ?>
                                
                                <!-- NEW: Button-specific Watch Online -->
                                <?php if (!empty($button['button_watch_online'])): ?>
                                <div class="episode-button-watch-online" style="margin-bottom: 10px;">
                                    <a href="javascript:void(0)" onclick="showAdAndRedirect('<?php echo esc_url($button['button_watch_online']); ?>')" class="btn btn-primary btn-user" style="background: #007cba; color: white; padding: 6px 16px; font-size: 13px; font-weight: bold;">
                                        <b class="btn-text"> 
                                            <i class="fas fa-play-circle"></i> 
                                            Watch 
                                            Online
                                            <i class="fas fa-play-circle"></i> 
                                        </b>
                                    </a>
                                </div>
                                <?php endif; ?>
                                
                                <div class="d-flex justify-content-center">
                                    <?php if (!empty($button['url'])): ?>
                                        <!-- Episode button with link - direct download -->
                                        <a href="javascript:void(0)" onclick="showAdAndRedirect('<?php echo esc_url($button['url']); ?>')" class="btn btn-dark btn-user main-button" style="padding: 6px 14px; font-size: 12px;">
                                            <b class="btn-text"> 
                                                <i class="fas fa-cloud-download-alt"></i> 
                                                <?php echo esc_html($button['text']); ?> 
                                            </b>
                                        </a>
                                    <?php else: ?>
                                        <!-- Episode button without link - toggles additional buttons -->
                                        <a href="javascript:void(0)" class="btn btn-dark btn-user main-button-toggle" data-target="episodeAdditionalButtons<?php echo $section_index . '_' . $button_index; ?>" style="padding: 6px 14px; font-size: 12px;">
                                            <b class="btn-text"> 
                                                <i class="fas fa-cloud-download-alt"></i> 
                                                <?php echo esc_html($button['text']); ?> 
                                            </b>
                                        </a>
                                    <?php endif; ?>
                                </div>
                                
                                <!-- Additional Buttons for Episode Button -->
                                <?php 
                                $episode_additional_buttons = isset($button['additional_buttons']) ? $button['additional_buttons'] : array();
                                if (!empty($episode_additional_buttons)): 
                                ?>
                                <div class="additional-buttons-container mt-2" id="episodeAdditionalButtons<?php echo $section_index . '_' . $button_index; ?>" style="display: none;">
                                    <div class="d-flex flex-wrap justify-content-center gap-2">
                                        <?php foreach ($episode_additional_buttons as $add_index => $add_button): ?>
                                            <?php if (!empty($add_button['text']) && !empty($add_button['url'])): ?>
                                            <a href="javascript:void(0)" onclick="showAdAndRedirect('<?php echo esc_url($add_button['url']); ?>')" class="btn btn-outline-dark additional-button" style="padding: 5px 10px; font-size: 11px; font-weight: bold; margin: 2px;">
                                                <b class="btn-text"> 
                                                    <i class="fas fa-download"></i> 
                                                    <?php echo esc_html($add_button['text']); ?> 
                                                </b>
                                            </a>
                                            <?php endif; ?>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>
        </div>
        <?php endif; ?>
    <?php endforeach; ?>
<?php endif; ?>

<div class="card-body">
<hr width="100%" height="1px" color="#fff"/>
</div>

<div class="container mt-6 mb-6 p-10 shadow-rounded shadow-lg rounded-lg border-left-primary">                
    <div class="row">
        <div class="col-12 text-center d-flex flex-wrap justify-content-center">
            <img src="//cdn.jsdelivr.net/gh/imsam304/898yw8@main/joinfbgrp.png" onClick="window.open('<?php echo $movielinkbd['facebook']; ?>');" alt="Join Facebook Group" class="img-fluid rounded-md mb-2 mx-2 b-error" style="max-width: 250px;cursor:pointer"/>
            <img src="//cdn.jsdelivr.net/gh/imsam304/898yw8@main/jointggrp.png" onClick="window.open('<?php echo $movielinkbd['telegram']; ?>');" alt="Join Telegram Group" class="img-fluid rounded-md mb-2 mx-2 b-error" style="max-width: 250px;cursor:pointer"/>
        </div>
    </div>
</div>

<!-- Content Box Start -->
<div id="content-warpper">
	<?php the_content();?>
</div>
<!-- Content Box End -->

<?php get_template_part('/templates/posts/also-downloads');?>

<p class="text-sm mt-4 mb-4 text-teal font-semibold text-center" style="word-wrap: break-word;">
	⚠️ Note: Some ads will appear on the site, which we hope you'll tolerate and support us through 🤝
</p>

<div class="container mt-6 mb-6 p-2 shadow-rounded shadow-lg rounded-lg border-left-warning">
<p class="mb-4 text-gray text-center" style="word-wrap: break-word; font-size: larger;">
  Thank you so much for visiting AAMovies.com — we truly appreciate your time! 😊
To make your experience smoother: always type AAMovies.com directly to access the site. When searching for movies, use the correct name to find downloads easily. For the latest updates and releases, join our Telegram channel. And just so you know, we don't upload Bangladeshi hall prints due to low quality — we're all about giving you the best!
</p>
</div>

<?php endwhile;
else : get_template_part('/templates/no-results');
endif; ?>
	</section>
</main>

<style>
/* Style for badges in proper left-to-right row */
.badges-row .rating-badge {
    background: #ff0000;
    color: white;
    padding: 4px 8px;
    border-radius: 4px;
    font-size: 12px;
    font-weight: bold;
    display: inline-block;
}

.badges-row .pinned-badge {
    background: #ff9800;
    color: white;
    padding: 4px 8px;
    border-radius: 4px;
    font-size: 10px;
    font-weight: bold;
    display: inline-block;
}

.badges-row .new-badge {
    background: #ff4500;
    color: white;
    padding: 4px 8px;
    border-radius: 4px;
    font-size: 10px;
    font-weight: bold;
    display: inline-block;
}

/* Additional buttons styling */
.button-with-additional {
    position: relative;
}

.additional-buttons-container {
    transition: all 0.3s ease;
    overflow: hidden;
}

.additional-button {
    font-size: 14px;
    padding: 8px 20px;
    font-weight: bold;
}

.main-button-toggle.active {
    background: #495057 !important;
}

/* Ensure all buttons have consistent styling */
.btn-user {
    padding: 6px 14px;
    font-size: 12px;
    font-weight: bold;
    margin: 5px;
}

/* Episode section styling */
.episode-section {
    position: relative;
}

.episode-badge {
    z-index: 2;
}

/* Remove white border from main episode heading */
.text-md[style*="border-bottom"] {
    border-bottom: none !important;
}

/* Episode title styling */
.episode-title-box {
    border: 1px solid #4ecdc4;
    border-radius: 4px;
    background: transparent;
}

.episode-title h4 {
    color: #333;
    font-weight: bold;
}

/* Episode watch online button - Same Blue as Main */
.episode-watch-online .btn-user {
    background: #007cba !important;
    color: white !important;
}

/* Button-specific watch online - NOW SAME BLUE AS MAIN */
.episode-button-watch-online .btn-user {
    background: #007cba !important;
    color: white !important;
}

/* Simple gap between watch online and download buttons */
.episode-download-buttons {
    margin-top: 10px;
}
</style>

<script>
// Copy URL function
document.getElementById('copy-url-btn').addEventListener('click', function() {
    var url = window.location.href;
    navigator.clipboard.writeText(url).then(function() {
        var originalText = this.innerHTML;
        this.innerHTML = 'Copied!';
        this.style.background = '#28a745';
        
        setTimeout(() => {
            this.innerHTML = originalText;
            this.style.background = '#007cba';
        }, 2000);
    }.bind(this));
});

// Toggle additional buttons for main buttons without links
document.querySelectorAll('.main-button-toggle').forEach(button => {
    button.addEventListener('click', function(e) {
        e.preventDefault();
        e.stopPropagation();
        
        var targetId = this.getAttribute('data-target');
        var targetElement = document.getElementById(targetId);
        
        if (!targetElement) return;
        
        // Close all other additional buttons first
        document.querySelectorAll('.additional-buttons-container').forEach(container => {
            if (container.id !== targetId) {
                container.style.display = 'none';
            }
        });
        
        document.querySelectorAll('.main-button-toggle').forEach(btn => {
            if (btn !== this) {
                btn.classList.remove('active');
            }
        });
        
        // Toggle current additional buttons
        if (targetElement.style.display === 'none' || targetElement.style.display === '') {
            targetElement.style.display = 'block';
            this.classList.add('active');
        } else {
            targetElement.style.display = 'none';
            this.classList.remove('active');
        }
    });
});

// Close additional buttons when clicking outside
document.addEventListener('click', function(e) {
    if (!e.target.closest('.button-with-additional')) {
        document.querySelectorAll('.additional-buttons-container').forEach(container => {
            container.style.display = 'none';
        });
        document.querySelectorAll('.main-button-toggle').forEach(btn => {
            btn.classList.remove('active');
        });
    }
});

// Aamovies redirect function for download buttons
function showAdAndRedirect(url) {
	// Open ad in new tab
	var adWindow = window.open('https://sunkendifferextreme.com/ehnbus360e?key=a30f9a2ed9acb00aa432448fe9a9e6fa', '_blank');
	
	// Redirect to actual download after delay
	setTimeout(function() {
		window.location.href = url;
	}, 800);
}

// Modify all content links to show ad first
document.querySelectorAll('#content-warpper a').forEach(link => {
	link.addEventListener('click', function(e) {
		e.preventDefault();
		var originalHref = this.href;
		var adWindow = window.open('https://sunkendifferextreme.com/ehnbus360e?key=a30f9a2ed9acb00aa432448fe9a9e6fa', '_blank');
		
		setTimeout(function() {
			window.location.href = originalHref;
		}, 800);
	});
});
</script>

<?php get_footer();