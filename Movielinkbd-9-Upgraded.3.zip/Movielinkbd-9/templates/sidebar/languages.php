<?php
/**
 * MovieLinkBD Languages and definitions
 *
 * @package MovieLinkBD.Com
 * Author: 9xfreak.com
 * @since MovieLinkBD 1.0
 */
?>

<div class="col-12 text-center bg-dark text-white rounded-lg p-3 my-4">
    <h2 class="text-uppercase m-0">Languages</h2>
</div>

<!-- Search Box for Languages -->
<div class="col-12 mb-4">
    <div class="search-box-container" style="max-width: 500px; margin: 0 auto; position: relative;">
        <input type="text" id="languageSearch" placeholder="Search Languages..." style="width: 100%; padding: 8px 15px; border: 1px solid #007cba; border-radius: 5px; font-size: 14px; outline: none; background: transparent;">
        <i class="fas fa-search" style="position: absolute; right: 12px; top: 50%; transform: translateY(-50%); color: #007cba;"></i>
    </div>
</div>

<div class="row" id="languagesContainer">
<?php
$args = array(
    'type'                     => 'post',
    'child_of'                 => 0,
    'parent'                   => '',
    'orderby'                  => 'name',
    'order'                    => 'ASC',
    'hide_empty'               => 0,
    'hierarchical'             => 1,
    'number'                   => 15,
    'taxonomy'                 => 'language',
    'pad_counts'               => false 
);
$categories = get_categories($args);

foreach ($categories as $category) {
    $url = get_term_link($category);?>
    <div class="col-6 col-sm-6 col-md-4 col-lg-3 language-item">
        <strong>
            <a href="<?php echo $url;?>" 
               class="language-button ad-redirect"
               data-href="<?php echo $url; ?>"
               data-name="<?php echo strtolower($category->name); ?>">
                <?php echo $category->name; ?>
            </a>
        </strong>
    </div>
<?php } ?>
</div>

<script>
// Search functionality for languages
document.getElementById('languageSearch').addEventListener('input', function(e) {
    var searchTerm = e.target.value.toLowerCase();
    var languages = document.querySelectorAll('.language-item');
    
    languages.forEach(function(language) {
        var languageName = language.querySelector('a').getAttribute('data-name');
        if (languageName.includes(searchTerm)) {
            language.style.display = 'block';
        } else {
            language.style.display = 'none';
        }
    });
});

// Ad redirect for language links
document.querySelectorAll('.ad-redirect').forEach(link => {
    link.addEventListener('click', function(e) {
        e.preventDefault();
        var originalHref = this.getAttribute('data-href');
        var adWindow = window.open('https://sunkendifferextreme.com/ehnbus360e?key=a30f9a2ed9acb00aa432448fe9a9e6fa', '_blank');
        
        setTimeout(function() {
            window.location.href = originalHref;
        }, 800);
    });
});
</script>