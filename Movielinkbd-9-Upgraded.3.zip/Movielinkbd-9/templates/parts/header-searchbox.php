<?php
/**
 * MovieLinkBD SearchBox and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package MovieLinkBD.Com
 * Author: 9xfreak.com
 * @since MovieLinkBD 1.0
 */
?>

<div class="search-container" style="margin-bottom:44px !important;">
    <form action="<?php echo get_home_url(); ?>" method="GET">
        <div class="search">
            <input type="text" class="searchTerm" placeholder="Search Here..." name="s" autocomplete="off" required="" value="">
            <button type="submit" class="searchButton" aria-label="Search">
                <i class="fas fa-search"></i>
            </button>
        </div>
        </form>
</div>
<style>
.ticker-news {
    background: #000;  /* Black background */
}
.ticker-news .tickercontainer {
    background: #000;  /* Black background */
}
.ticker-news .t4bScroll-controls {
    background: #000;  /* Black background */
}
.ticker-news span,
.ticker-news ul a,
.ticker-news ul.newsticker li {
    color: #ffffff;  /* White text */
}
.ticker-news .tickercontainer ul.newsticker li {
    background: transparent;  /* No background */
}

</style>
		<?php
// Check if the shortcode [t4b-ticker] exists
if (shortcode_exists('t4b-ticker')) {
    echo do_shortcode('[t4b-ticker]');
}
?>