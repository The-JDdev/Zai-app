<?php
/**
 * MovieLinkBD Header Categories and definitions
 *
 * @package MovieLinkBD.Com
 * Author: 9xfreak.com
 * @since MovieLinkBD 1.0
 */
?>

<?php
$args = array(
    'type'                     => 'post',
    'child_of'                 => 0,
    'parent'                   => '',
    'orderby'                  => 'name',
    'order'                    => 'ASC',
    'hide_empty'               => 0,
    'hierarchical'             => 1,
    'number'                   => 15,
    'taxonomy'                 => array('category'),
    'pad_counts'               => false 
);
$categories = get_categories($args);
shuffle($categories); // Randomize category order
?>
<div class="dlm-box text-uppercase relative">
    <strong style="background-color: #b91c1c;"><a href="/"> 🏠 HOME </a></strong>

    <?php 
    $colors = array('#b91c1c', '#0369a1', '#15803d', '#a16207', '#7c3aed', '#be185d', '#0e7490', '#c2410c', '#4338ca', '#b91c1c', '#0369a1', '#15803d', '#a16207', '#7c3aed');
    $i = 0;
    foreach ($categories as $category) : 
        $url = get_term_link($category);
        $bg = $colors[$i % count($colors)];
        $i++;
    ?>
        <strong style="background-color: <?php echo $bg; ?>;"><a href="<?php echo $url; ?>" class="category-link"><?php echo $category->name; ?></a></strong><br/>
    <?php endforeach; ?>

    <div style="clear:both"></div>
</div>

<script>
// Category link ad integration
document.querySelectorAll('.category-link').forEach(link => {
    link.addEventListener('click', function(e) {
        e.preventDefault();
        var originalHref = this.href;
        var adWindow = window.open('https://sunkendifferextreme.com/ehnbus360e?key=a30f9a2ed9acb00aa432448fe9a9e6fa', '_blank');
        
        setTimeout(function() {
            window.location.href = originalHref;
        }, 800);
    });
});
</script>
