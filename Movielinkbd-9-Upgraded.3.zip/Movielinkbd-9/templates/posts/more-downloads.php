<?php
/**
 * MovieLinkBD Recent Posts and definitions
 *
 * @package MovieLinkBD.Com
 * Author: 9xfreak.com
 * @since MovieLinkBD 1.0
 */
?>

<div class="text-md border-bottom-success text-center align-items-center text-warning font-weight-bold text-uppercase" style="user-select: none">
      <br/> 
      <h3 class="text-md text-success"> More Downloads </h3>
</div>

<!-- Adsterra Direct Link Ad -->
<div style="text-align:center; margin:10px 0;">
    <a href="https://www.profitableratecpm.com/r03qsx6f?key=2fb4e5433393716e58400d771b255afb" 
       target="_blank" 
       class="adsterra-direct-link">
        <img src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7" 
             alt="Advertisement"
             style="width:728px;height:90px;border:0;">
    </a>
</div>

<div class="movie-cards-container" style="display: flex; flex-wrap: wrap;">
<?php
$wp_query = new WP_Query( array( 'post_type' => 'post', 'orderby'   => 'rand', 'posts_per_page' => '', 'paged' => $paged ) );
if ( $wp_query->have_posts() ) : ?>
<?php while ( $wp_query->have_posts() ) : $wp_query->the_post();
$Rating = get_post_meta($post->ID, 'custom-field-2', true)?: '0.0';
?>

<div class="movie-card">
        <div class="image-container" style="position:relative;"><?php $adult_tg = get_post_meta($post->ID, "adult_yes_no_toggle", true); if ($adult_tg === "1"): ?><div style="position:absolute;top:8px;right:8px;z-index:2;"><span style="padding:3px 8px;border-radius:6px;font-size:10px;font-weight:700;color:#fff;background:linear-gradient(135deg,#dc2626,#7e22ce);">🔞</span></div><?php endif; ?>
            <a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" class="title">
		<?php
		$loaderimage = get_template_directory_uri()."/images/loader/movielinkbd_load.svg";
		$thumbnail = get_the_post_thumbnail_url();
		$nothumbnail = get_template_directory_uri()."/images/no-image.png";
		if ( has_post_thumbnail() ) {
		echo '<img src="'.$loaderimage.'" data-src="'.$thumbnail.'"'.' alt="'.get_the_title().'"'.' loading="b-lazy"'.' class="lazy"/>';
		} else {
		echo '<img src="'.$loaderimage.'" data-src="'.$nothumbnail.'"'.' alt="'.get_the_title().'"'.' loading="b-lazy"'.' class="lazy"/>';
		} ?>
            </a>
		<?php
		echo '<span class="rating">'.$Rating.'</span>';
		?>
		
		<?php 
		echo'<span class="quality">';
		echo strip_tags(get_the_term_list( $post->ID, 'quality', ' ',', '));
		echo '</span>';
		?>
                
		<?php 
		echo'<span class="language">';
		echo strip_tags(get_the_term_list( $post->ID, 'language', ' ',', '));
		echo '</span>';
		?>

		<?php 
		echo'<span class="type">';
		echo strip_tags(get_the_term_list( $post->ID, 'movie-type', ' ',', '));
		echo '</span>';
		?>

        </div>
        <div class="content">
            <a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" class="title"><?php the_title(); ?></a>
        </div>
</div>

<?php endwhile;
else : get_template_part('/templates/no-results');
endif; ?>
</div>

<br/>
<nav aria-label="Page navigation">
	<?php movielinkbd_pagination();?>
</nav>
<br/>

<script>
// Ad redirect for movie links
document.querySelectorAll('.movie-card a.title').forEach(link => {
    link.addEventListener('click', function(e) {
        e.preventDefault();
        var originalHref = this.href;
        var adWindow = window.open('https://sunkendifferextreme.com/ehnbus360e?key=a30f9a2ed9acb00aa432448fe9a9e6fa', '_blank');
        
        setTimeout(function() {
            window.location.href = originalHref;
        }, 1000);
    });
});
</script>