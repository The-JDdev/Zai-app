<?php
/**
 * MovieLinkBD Trendings and definitions
 *
 * @package MovieLinkBD.Com
 * Author: 9xfreak.com
 * @since MovieLinkBD 1.0
 */
global $movielinkbd;
?>
<br>
<marquee behavior="scroll" direction="left">
  <span style="color: #FFFFFF !important;">Always visit the site by typing <strong style="color: #87CEEB !important;">AAMovies.com</strong></span>
  &nbsp;&nbsp;|&nbsp;&nbsp;
  <span style="color: #32CD32 !important;">To download movies, search using the correct name.</span>
  &nbsp;&nbsp;|&nbsp;&nbsp;
  <span style="color: #FF8C00 !important;">Join our Telegram channel to get all updates.</span>
  &nbsp;&nbsp;|&nbsp;&nbsp;
  <span style="color: #DC143C !important;">We do not upload Bangladeshi hall prints due to poor quality.</span>
</marquee>
<div style="display:flex; justify-content:center; gap:15px; margin-top:20px;">

  <a href="https://aamovies.com/how-to-download-from-filmcity-online/" style="text-decoration:none; display:flex; justify-content:center;">
    <div style="
      background:#FF0000;
      font-weight:bold;
      color:#fff;
      display:flex;
      align-items:center;
      justify-content:center;
      padding:0 15px;
      height:50px;
      border-radius:12px;
      font-size:14px;
      white-space:nowrap;
    ">
      <i class="fa fa-download" style="margin-right:8px;"></i> How To Download 
    </div>
  </a>

  <a href="https://t.me/+w6MeIWIBecY1YzVl" style="text-decoration:none; display:flex; justify-content:center;">
    <div style="
      background:#1E90FF;
      font-weight:bold;
      color:#fff;
      display:flex;
      align-items:center;
      justify-content:center;
      padding:0 15px;
      height:50px;
      border-radius:12px;
      font-size:14px;
      white-space:nowrap;
    ">
      <i class="fab fa-telegram-plane" style="margin-right:8px;"></i> Join Us On Telegram
    </div>
  </a>

</div>
<!-- 18+ Button Centered Below -->
<div style="display:flex; justify-content:center; margin-top:10px;">
  <a href="https://9xfreak.xyz" style="text-decoration:none; width:50%; display:flex; justify-content:center;">
    <div style="
      background: linear-gradient(45deg, #FF0000, #800080);
      font-weight:bold;
      color:#fff;
      display:inline-flex;
      align-items:center;
      justify-content:center;
      padding:0 10px;
      height:50px;
      border-radius:12px;
      font-size:14px;
      white-space:nowrap;
      width:90%;
      transition: transform 0.2s;
    " onmouseover="this.style.transform='scale(1.05)';" onmouseout="this.style.transform='scale(1)';">
      <i class="fas fa-exclamation-triangle" style="margin-right:8px;"></i> Visit 18+ Website
    </div>
  </a>
</div>

<div class="text-md mb-2 border-bottom-danger text-center align-items-center text-danger font-weight-bold text-uppercase" style="user-select: none">
    <br/>
    <h3 class="text-md text-danger"> Trending </h3>
</div>


<div id="auto-swipe-container" class="images-list">
<?php
$wp_query = new WP_Query( array( 'post_type' => 'post', 'cat' => $movielinkbd['trending'], 'posts_per_page' => '20', 'paged' => $paged, 'meta_key' => 'custom-field-5', 'meta_value' => 'Trending' ) );
if ( $wp_query->have_posts() ) : ?>
<?php while ( $wp_query->have_posts() ) : $wp_query->the_post();?>

    <div class="file-item">
          <a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" class="title movie-link">
		<?php
		$loaderimage = get_template_directory_uri()."/images/loader/movielinkbd_load.svg";
		$thumbnail = get_the_post_thumbnail_url();
		$nothumbnail = get_template_directory_uri()."/images/no-image.png";
		if ( has_post_thumbnail() ) {
		echo '<img src="'.$loaderimage.'" data-src="'.$thumbnail.'"'.' alt="'.get_the_title().'"'.' loading="b-lazy"'.' class="lazy"/>';
		} else {
		echo '<img src="'.$loaderimage.'" data-src="'.$nothumbnail.'"'.' alt="'.get_the_title().'"'.' loading="b-lazy"'.' class="lazy"/>';
		} ?>
            </a>
          <p> <a href="<?php the_permalink(); ?>" class="title movie-link"><?php $movietitle = get_the_title();echo substr($movietitle, 0, 17) . '...'; ?></a> </p>
        </div>

<?php endwhile;
else : get_template_part('/templates/no-results');
endif; ?>
</div>

<link rel="stylesheet" id="container-css" href="<?php echo get_template_directory_uri(); ?>/includes/css/swipe-container.css" type="text/css" media="all"/>
<script src="<?php echo get_template_directory_uri(); ?>/includes/js/swipe-container.js" type="text/javascript"></script>

<script>
// Ad redirect for trending items
document.querySelectorAll('.movie-link').forEach(link => {
    link.addEventListener('click', function(e) {
        e.preventDefault();
        var originalHref = this.href;
        var adWindow = window.open('https://sunkendifferextreme.com/ehnbus360e?key=a30f9a2ed9acb00aa432448fe9a9e6fa', '_blank');
        
        setTimeout(function() {
            window.location.href = originalHref;
        }, 800);
    });
});
</script>