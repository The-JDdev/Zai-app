<?php
/**
 * MovieLinkBD Recent Posts and definitions
 *
 * @package MovieLinkBD.Com
 * Author: 9xfreak.com
 * @since MovieLinkBD 1.0
 */
?>

<div class="text-md border-bottom-success text-center align-items-center text-warning font-weight-bold text-uppercase" style="user-select: none">
      <br/> 
      <h3 class="text-md text-success"> Recently Updated </h3>
</div>

<div class="movie-cards-container" style="display: flex; flex-wrap: wrap;">
<?php
$wp_query = new WP_Query( array( 'post_type' => 'post', 'posts_per_page' => '', 'paged' => $paged ) );
if ( $wp_query->have_posts() ) : ?>
<?php while ( $wp_query->have_posts() ) : $wp_query->the_post();
$Rating = get_post_meta($post->ID, 'custom-field-2', true)?: '0.0';

// New fields for recent
$is_episode = get_post_meta($post->ID, 'is_episode', true);
$episode_range = get_post_meta($post->ID, 'episode_range', true);
$pinned_badge = get_post_meta($post->ID, 'pinned_badge', true);
$new_badge = get_post_meta($post->ID, 'new_badge', true);
$adult_toggle = get_post_meta($post->ID, 'adult_yes_no_toggle', true);

// Time ago calculation
$post_time = get_the_time('U');
$current_time = current_time('U');
$time_difference = human_time_diff($post_time, $current_time);
?>

<div class="movie-card">
        <div class="image-container" style="position:relative;">
            <?php if ($adult_toggle === '1'): ?>
            <div style="position:absolute;top:8px;right:8px;z-index:2;"><span style="padding:3px 8px;border-radius:6px;font-size:10px;font-weight:700;color:#fff;background:linear-gradient(135deg,#dc2626,#7e22ce);">🔞</span></div>
            <?php endif; ?>
            <!-- Badges in proper left-to-right row with new colors and smaller size -->
            <div class="badges-row" style="position: absolute; top: 6px; left: 6px; display: flex; align-items: center; gap: 3px; z-index: 2;">
                <?php
                // Rating badge (red) - always shows if rating exists
                if (!empty($Rating) && $Rating !== '0.0') {
                    echo '<span class="rating-badge" style="background: #ff0000; color: #fff; padding: 1px 5px; border-radius: 3px; font-size: 8px; font-weight: bold; display: inline-block;">'.$Rating.'</span>';
                }
                
                // Pinned badge (orange) - only if selected
                if ($pinned_badge === '1') {
                    echo '<span class="pinned-badge" style="background: #ff9800; color: white; padding: 1px 5px; border-radius: 3px; font-size: 8px; font-weight: bold; display: inline-block;">Pinned</span>';
                }
                
                // New badge (red-orange mix) - only if selected
                if ($new_badge === '1') {
                    echo '<span class="new-badge" style="background: #ff4500; color: white; padding: 1px 5px; border-radius: 3px; font-size: 8px; font-weight: bold; display: inline-block;">New</span>';
                }
                ?>
            </div>

            <a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" class="title movie-link">
		<?php
		$loaderimage = get_template_directory_uri()."/images/loader/movielinkbd_load.svg";
		$thumbnail = get_the_post_thumbnail_url();
		$nothumbnail = get_template_directory_uri()."/images/no-image.png";
		if ( has_post_thumbnail() ) {
		echo '<img src="'.$loaderimage.'" data-src="'.$thumbnail.'"'.' alt="'.get_the_title().'"'.' loading="b-lazy"'.' class="lazy"/>';
		} else {
		echo '<img src="'.$loaderimage.'" data-src="'.$nothumbnail.'"'.' alt="'.get_the_title().'"'.' loading="b-lazy"'.' class="lazy"/>';
		} ?>
            </a>
            
		<?php 
		echo'<span class="quality">';
		echo strip_tags(get_the_term_list( $post->ID, 'quality', ' ',', '));
		echo '</span>';
		?>
                
		<?php 
		echo'<span class="language">';
		echo strip_tags(get_the_term_list( $post->ID, 'language', ' ',', '));
		echo '</span>';
		?>

		<?php 
		echo'<span class="type">';
		echo strip_tags(get_the_term_list( $post->ID, 'movie-type', ' ',', '));
		echo '</span>';
		?>

        </div>
        <div class="content">
            <!-- Smaller time ago and episode info - Above title -->
            <div class="post-meta-info" style="margin-bottom: 5px; font-size: 10px; color: #666; line-height: 1.2;">
                <div style="margin-bottom: 2px;"><i class="fas fa-clock" style="margin-right: 3px; font-size: 9px;"></i><strong>Posted:</strong> <?php echo $time_difference; ?> ago</div>
                <?php if ($is_episode === '1' && !empty($episode_range)): ?>
                <div style="display: inline-block; padding: 1px 6px; border: 1px solid #007cba; border-radius: 8px; font-size: 9px;">
                    <i class="fas fa-play-circle" style="margin-right: 3px; font-size: 9px;"></i><strong></strong> <?php echo esc_html($episode_range); ?>
                </div>
                <?php endif; ?>
            </div>
            
            <a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" class="title movie-link"><?php the_title(); ?></a>
        </div>
</div>

<?php endwhile;
else : get_template_part('/templates/no-results');
endif; ?>
</div>

<br/>
<nav aria-label="Page navigation">
	<?php movielinkbd_pagination();?>
</nav>
<br/>

<script>
// Ad redirect for movie links
document.querySelectorAll('.movie-link').forEach(link => {
    link.addEventListener('click', function(e) {
        e.preventDefault();
        var originalHref = this.href;
        var adWindow = window.open('https://sunkendifferextreme.com/ehnbus360e?key=a30f9a2ed9acb00aa432448fe9a9e6fa', '_blank');
        
        setTimeout(function() {
            window.location.href = originalHref;
        }, 800);
    });
});
</script>