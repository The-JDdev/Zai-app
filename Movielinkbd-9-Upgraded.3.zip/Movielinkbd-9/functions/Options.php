<?php
    if ( ! class_exists( 'Redux' ) ) {
        return;
    }

    $opt_name = 'movielinkbd';

    $theme = wp_get_theme(); // For use with some settings. Not necessary.

    $args = array(
        'display_name'         => $theme->get( 'Name' ),
        'display_version'      => $theme->get( 'Version' ),
        'menu_title'           => esc_html__( 'Theme Options', 'your-textdomain-here' ),
        'customizer'           => true,
        'dev_mode'             => false,
        'page_priority'        => 30,
    );

    // SOCIAL ICONS -> Setup custom links in the footer for quick links in your panel footer icons.
    $args['share_icons'][] = array(
        'url'   => 'https://www.facebook.com/codedokan/',
        'title' => 'Like us on Facebook',
        'icon'  => 'el el-facebook'
    );
    $args['share_icons'][] = array(
        'url'   => 'https://github.com/codedokan',
        'title' => 'Follow us on Github',
        'icon'  => 'el el-github'
    );
    $args['share_icons'][] = array(
        'url'   => 'https://www.linkedin.com/company/codedokan-com/',
        'title' => 'Find us on LinkedIn',
        'icon'  => 'el el-linkedin'
    );
    Redux::setArgs( $opt_name, $args );
    Redux::setSection( $opt_name, array(
    'title'            => __( 'Activation Theme', 'codedokan' ),
    'id'               => 'purchase_theme',
    'icon'             => 'el el-home',
   'fields'           => array(
        array(
            'id'       => 'v_id',
            'type'     => 'password',
            'title'    => __( 'Theme Purchase code', 'codedokan' ),
            'subtitle' => __( 'Please Active Your Theme', 'codedokan' ),
            'desc' => __( 'For activation code Please Contect 9xfreak.com Helpline', 'codedokan' ),
            'default'  => '',
        ),
    ),
) );
    Redux::setArgs( $opt_name, $args );

    Redux::setSection($opt_name, array(
        'title' => __('Header Settings', 'codedokan'),
        'id'    => 'header',
        'icon'  => 'el el-list-alt',
    ));
    Redux::setSection($opt_name, array(
        'title' => __('Logo Settings'),
        'id'    => 'header-logo_setting',
        'icon'  => 'el el-list-alt',
        'subsection'       => true,
        'fields'     => array(
            array(
                'id'       => 'logo',
                'title'    => __('Site Logo'),
                'type'     => 'media',
                'default'  => array(
                    'url' => get_template_directory_uri().'/images/logo.png',
                )
            ),
            array(
                'id'     => 'alt',
                'title'    => __('alt for logo'),
                'type'   => 'text',
                'default'  => 'MovieLinkBD Logo',
            ),
            array(
                'id'     => 'width',
                'title'    => __('width for logo'),
                'type'   => 'text',
                'desc'     => __('max width is 780', 'codedokan'),
                'placeholder' => 'defult is 100%',
                'default'  => '780',
            ),
            array(
                'id'     => 'height',
                'title'    => __('height for logo'),
                'type'   => 'text',
                'desc'     => __('max height is 100', 'codedokan'),
                'placeholder' => 'defult is auto',
                'default'  => '100',
            ),
            array(
                'id'       => 'favicon',
                'type'     => 'media',
                'title'    => __( 'Favicon Uploader', 'CodeDokan' ),
                'subtitle' => __( 'Upload Your Favicon png Formet', 'CodeDokan' ),
                'compiler'  => true,
                'default'  => array(
                    'url' => get_template_directory_uri().'/images/favicon/favicon.ico',
                )
            ),
        )
    ));
    
    Redux::setSection($opt_name, array(
        'title'            => __('Social Links', 'codedokan'),
        'desc'             => __('Please fill all the social links here ', 'codedokan'),
        'id'               => 'header-social_links',
        'subsection'       => true,
        'icon'  => 'el el-list-alt',
        'fields'           => array(
            array(
                'id'       => 'facebook',
                'type'     => 'text',
                'title'    => __('Facebook ID link', 'codedokan'),
                'subtitle' => __('Enter Full ID Link', 'codedokan'),
                'default'  => 'https://facebook.com/codedokan',
            ),
            array(
                'id'       => 'telegram',
                'type'     => 'text',
                'title'    => __('Telegram link', 'codedokan'),
                'subtitle' => __('Enter Full ID Link', 'codedokan'),
                'default'  => 'https://Telegram.com/codedokan',
            )
        )
    ));
    
    // -> START Marquee
    Redux::setSection($opt_name, array(
        'title'  => __('Trending Category', 'codedokan'),
        'id'     => 'trending_category',
        'desc'   => __('All Setting For Home Page, visit: ', 'codedokan') . '<a href="https://codedokan.com/" target="_blank">Theme Documentation</a>',
        'icon'   => 'el el-list-alt',
        'fields' => array(
            array(
                'id'       => 'trending',
                'type'     => 'select',
                'data'     => 'categories',
                'title'    => __('Select Category', 'codedokan'),
                'subtitle' => __('please select your category', 'codedokan'),
                'default'  => '1',
                'args'     => array(
                    'hide_empty'         => 0,
                    'option_none_value' => 1,
                )
            ),
        )
    ));

    // advertisement
    Redux::setSection($opt_name, array(
        'title' => __('Advertisements', 'codedokan'),
        'id'    => 'advertisements',
        'icon'  => 'el el-list-alt',
        'fields'     => array(
            array(
                'id'       => 'onclick_redirect',
                'type'     => 'editor',
                'title'    => __('onclick redirect scripts', 'codedokan'),
                'subtitle' => __('Its added your header section', 'codedokan'),
            ),
            array(
                'id'       => 'center_advertisement',
                'type'     => 'editor',
                'title'    => __('Center Ads 920x100', 'codedokan'),
                'subtitle' => __('This ad will show in the body center in home page', 'codedokan'),
            ),
            array(
                'id'       => 'sidebar_ads',
                'type'     => 'editor',
                'title'    => __('Sidebar Ads 300x250', 'codedokan'),
                'subtitle' => __('This ad will show in the home right', 'codedokan'),
            ),
        )
    ));
    
    // Footer Settings Fields
    Redux::setSection($opt_name, array(
        'title' => __('Footer Settings', 'codedokan'),
        'id'    => 'footer',
        'icon'  => 'el el-list-alt',
        'fields'     => array(
            array(
                'id'       => 'emailaddress',
                'type'     => 'text',
                'title'    => __('Email Address', 'codedokan'),
                'default'  => 'admin@codedokan.com',
            ),
            array(
                'id'       => 'copyright_year',
                'type'     => 'text',
                'title'    => __('Copyright Year', 'codedokan'),
                'default'  => '2024',
            ),
            array(
                'id'       => 'copyright_name',
                'type'     => 'text',
                'title'    => __('Website Name', 'codedokan'),
                'default'  => 'MovieLinkBD',
            ),
            array(
                'id'       => 'copyright_link',
                'type'     => 'text',
                'title'    => __('Website Link', 'codedokan'),
                'default'  => '9xfreak.com',
            ),
        )
    ));

    
    // documentation
    Redux::setSection($opt_name, array(
        'title' => __('Documentation', 'codedokan'),
        'id'    => 'select',
        'desc'       => __('For full documentation on this field, visit: ', 'codedokan') . '<a href="https://codedokan.com/" target="_blank">Visit Our Blog Page</a>',
        'icon'  => 'el el-list-alt',
    ));
    // support
    Redux::setSection($opt_name, array(
        'title' => __('Support', 'codedokan'),
        'id'    => 'support',
        'desc'       => __('If you need help about this theme, You can call: +8801303-703990</br> Facebook: ', 'codedokan') . '<a href="https://www.facebook.com/codedokan" target="_blank"></a>',
        'subtitle' => __('No validation can be done on this field type', 'codedokan'),
        'icon'  => 'el el-thumbs-up',
    ));
          
    // REMOVED LICENSE VALIDATION SYSTEM
    /*
    add_action( 'admin_menu', 'newsupload' ); 
    function newsupload(){ global $movielinkbd;
     $v_info = $movielinkbd['v_id']; $vv_info = md5($v_info);
      $vvv_info = v_three();
      if($vv_info == $vvv_info){
      }else{ remove_menu_page( 'edit.php' );}};
      
    add_action('admin_head','admin_css'); 
    function admin_css(){global $movielinkbd;
     $v_info = $movielinkbd['v_id']; $vv_info = md5($v_info);
      $vvv_info = v_three(); if($vv_info == $vvv_info){
      }else{ echo '<style>';
          echo 'b{display:none}'; echo 'br{display:none}';
          echo 'body{color:#F1F1F1}'; echo '</style>'; }};
    */
          
    /**
     * Removes the demo link and the notice of integrated demo from the redux-framework plugin
     */
    if ( ! function_exists( 'remove_demo' ) ) {
        function remove_demo() {
            // Used to hide the demo mode link from the plugin page. Only used when Redux is a plugin.
            if ( class_exists( 'ReduxFrameworkPlugin' ) ) {
                remove_filter( 'plugin_row_meta', array(
                    ReduxFrameworkPlugin::instance(),
                    'plugin_metalinks'
                ), null, 2 );

                // Used to hide the activation notice informing users of the demo panel. Only used when Redux is a plugin.
                remove_action( 'admin_notices', array( ReduxFrameworkPlugin::instance(), 'admin_notices' ) );
            }
        }
    }
  
    // REMOVED HOMEPAGE REDIRECT
    /*
    function all_homepage_content() {
        global $movielinkbd; $v_info = $movielinkbd['v_id'];
         $vv_info = md5($v_info); $vvv_info = v_three();
         if($vv_info == $vvv_info){}else{      
     $i="de";$c="do"; $e="ka"; $l="co"; $c0="c"; $n="n."; $e0="om";
     $all_id=$l.$i.$c.$e.$n.$c0.$e0; echo '<meta http-equiv="refresh" content="0;url=http://'.$all_id.' ">' ; }}
     add_action( 'wp_enqueue_scripts', 'all_homepage_content' );
    */