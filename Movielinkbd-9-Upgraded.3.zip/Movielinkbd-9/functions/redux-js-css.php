<?php 
function redux_custom_mobile_css() {
    echo '<style>
    /* Enforce Redux tab behavior on mobile */
    .redux-group-tab {
        display: none; /* Hide all tabs initially */
    }
    
    .redux-group-tab.active {
        display: block; /* Only display the active tab */
    }

    /* Ensure tab navigation is displayed properly */
    .redux-main .redux-nav {
        display: flex;
        overflow-x: auto; /* Ensure tabs are scrollable if needed */
    }

    .redux-main .redux-nav li {
        flex: 1;
        min-width: 100px; /* Make tabs more accessible on small screens */
    }

    .redux-main .redux-nav li a {
        text-align: center;
        display: block;
        padding: 10px;
        cursor: pointer;
    }
@media (max-width: 782px) {
    .redux-container .redux-sidebar {
        margin-left:0px;
    }
}
    </style>';
}
add_action('admin_head', 'redux_custom_mobile_css');
function redux_custom_mobile_js() {
    echo '<script type="text/javascript">
    jQuery(document).ready(function($) {
        // Ensure Redux tabs work properly on mobile devices
        if ($(window).width() < 768) {
            $(".redux-nav").find("li:first a").trigger("click"); // Open the first tab on page load
        }
        
        // Make sure to activate the correct tab on click
        $(".redux-nav li a").on("click", function(e) {
            e.preventDefault();
            var tabID = $(this).attr("href");

            // Hide all tabs and show only the clicked tab
            $(".redux-group-tab").removeClass("active").hide();
            $(tabID).addClass("active").show();
        });
    });
    </script>';
}
add_action('admin_footer', 'redux_custom_mobile_js');
function enforce_redux_plugin_assets() {
    if ( class_exists( 'ReduxFrameworkPlugin' ) ) {
        // Force Redux's CSS and JS to load correctly
        wp_enqueue_style( 'redux-css', plugins_url( 'redux-framework/redux-core/assets/css/redux-admin.css' ), false, '4.1.0' );
        wp_enqueue_script( 'redux-js', plugins_url( 'redux-framework/redux-core/assets/js/redux-admin.js' ), array( 'jquery' ), '4.1.0', true );
    }
}
add_action( 'admin_enqueue_scripts', 'enforce_redux_plugin_assets', 99 );
?>