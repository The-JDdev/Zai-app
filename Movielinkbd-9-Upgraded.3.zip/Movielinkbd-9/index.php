<?php
/**
 * MovieLinkBD index and definitions
 *
 * @package MovieLinkBD.Com
 * Author: 9xfreak.com
 * @since MovieLinkBD 1.0
 */
get_header();
?>

	<?php get_template_part('/templates/posts/trendings');?>

	<!-- OTT Platform Section (from ref1) — with real logos -->
	<div class="ott-wrapper" style="max-width:1200px;margin:30px auto;padding:0 15px;">
		<div class="ott-container" style="background:#1a1b23;border-radius:16px;padding:20px;box-shadow:0 4px 16px rgba(0,0,0,0.4);border:1px solid #2a2b35;">
			<div class="ott-title-box" style="display:flex;align-items:center;gap:10px;margin-bottom:15px;">
				<h2 class="ott-h2" style="font-size:1.5rem;font-weight:800;color:#f8f9fc;margin:0;text-transform:uppercase;letter-spacing:1px;">
					<i class="fa-solid fa-tower-broadcast" style="color:#ff0a80;"></i> OTT Platform
				</h2>
				<div class="ott-bar" style="flex:1;height:3px;background:linear-gradient(to right,#ff0a80,transparent);border-radius:2px;"></div>
			</div>
			<div class="ott-playlist" id="ottScroll" style="display:flex;gap:15px;overflow-x:auto;padding-bottom:10px;scroll-behavior:smooth;-webkit-overflow-scrolling:touch;">
				<?php
				$ott_platforms = array(
					array('name' => 'Netflix', 'logo' => 'https://upload.wikimedia.org/wikipedia/commons/7/7a/Logonetflix.png', 'url' => '/category/netflix/'),
					array('name' => 'Amazon Prime', 'logo' => 'https://upload.wikimedia.org/wikipedia/commons/1/11/Amazon_Prime_Video_logo.png', 'url' => '/category/amazon-prime/'),
					array('name' => 'Disney+ Hotstar', 'logo' => 'https://upload.wikimedia.org/wikipedia/commons/3/3e/Disney%2B_Hotstar_logo.svg', 'url' => '/category/disney-hotstar/'),
					array('name' => 'HBO Max', 'logo' => 'https://upload.wikimedia.org/wikipedia/commons/d/d3/HBOMax.svg', 'url' => '/category/hbo-max/'),
					array('name' => 'Hulu', 'logo' => 'https://upload.wikimedia.org/wikipedia/commons/0/03/Hulu_logo.svg', 'url' => '/category/hulu/'),
					array('name' => 'Apple TV+', 'logo' => 'https://upload.wikimedia.org/wikipedia/commons/2/28/Apple_TV_Plus_logo.svg', 'url' => '/category/apple-tv/'),
					array('name' => 'Peacock', 'logo' => 'https://upload.wikimedia.org/wikipedia/commons/d/d3/NBCUniversal_Peacock_2023.svg', 'url' => '/category/peacock/'),
					array('name' => 'Paramount+', 'logo' => 'https://upload.wikimedia.org/wikipedia/commons/e/e4/Paramount_Plus_2021.svg', 'url' => '/category/paramount/'),
					array('name' => 'ZEE5', 'logo' => 'https://upload.wikimedia.org/wikipedia/commons/2/2b/ZEE5_logo.svg', 'url' => '/category/zee5/'),
					array('name' => 'SonyLIV', 'logo' => 'https://upload.wikimedia.org/wikipedia/commons/8/88/SonyLIV_2022.svg', 'url' => '/category/sony-liv/'),
					array('name' => 'Voot', 'logo' => 'https://upload.wikimedia.org/wikipedia/commons/4/4b/Voot.svg', 'url' => '/category/voot/'),
					array('name' => 'JioCinema', 'logo' => 'https://upload.wikimedia.org/wikipedia/commons/9/95/JioCinema_2022.svg', 'url' => '/category/jio-cinema/'),
					array('name' => 'MX Player', 'logo' => 'https://upload.wikimedia.org/wikipedia/commons/0/05/MX_Player_Logo.svg', 'url' => '/category/mx-player/'),
					array('name' => 'Crunchyroll', 'logo' => 'https://upload.wikimedia.org/wikipedia/commons/5/50/Crunchyroll_2022.svg', 'url' => '/category/crunchyroll/'),
				);
				foreach ($ott_platforms as $ott):
					$cat = get_category_by_slug(strtolower(str_replace(array('+', ' '), array('', '-'), $ott['name'])));
					$link = $cat ? get_term_link($cat) : home_url($ott['url']);
				?>
				<div class="ott-item" style="flex:0 0 auto;width:80px;height:80px;border-radius:10px;background:#22232e;display:flex;align-items:center;justify-content:center;transition:all 0.3s;border:2px solid transparent;">
					<a href="<?php echo $link; ?>" style="display:flex;flex-direction:column;align-items:center;justify-content:center;width:100%;height:100%;text-decoration:none;gap:4px;">
						<img src="<?php echo $ott['logo']; ?>" alt="<?php echo $ott['name']; ?>" style="width:48px;height:48px;object-fit:contain;border-radius:4px;" onerror="this.style.display='none'; this.nextElementSibling.style.display='block';"/>
						<span style="font-size:9px;color:#f8f9fc;text-align:center;display:none;"><?php echo $ott['name']; ?></span>
					</a>
				</div>
				<?php endforeach; ?>
			</div>
		</div>
	</div>
	<style>
	.ott-item:hover { border-color:#ff0a80 !important; transform:scale(1.1); box-shadow:0 4px 16px rgba(0,0,0,0.4); }
	#ottScroll::-webkit-scrollbar { height:6px; }
	#ottScroll::-webkit-scrollbar-track { background:#0e0f14; border-radius:3px; }
	#ottScroll::-webkit-scrollbar-thumb { background:#ff0a80; border-radius:3px; }
	</style>

	<?php get_template_part('/templates/posts/recents');?>
	<?php get_template_part('/sidebar');?>

<?php get_footer();?>
<script type='text/javascript' src='//sunkendifferextreme.com/e2/5b/7a/e25b7a7d319c7998d0efd502126b96d1.js'></script>
