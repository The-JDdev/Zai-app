<?php
/**
 * Template Name: Safe Embed Page
 * Purpose: Preserve theme structure & show any content/code exactly
 */

get_header();
?>

<main class="max-w-screen-xl mx-auto px-4 py-6">
    <section class="bg-white shadow-lg rounded-lg p-6">

        <?php 
        if ( have_posts() ) :
            while ( have_posts() ) : the_post(); ?>

                <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

                    <header class="entry-header mb-6 text-center">
                        <h1 class="entry-title text-3xl lg:text-4xl font-bold"><?php the_title(); ?></h1>
                    </header>

                    <!-- Safe content wrapper -->
                    <div class="entry-content">
                        <div class="safe-embed-container">
                            <?php the_content(); ?>
                        </div>
                    </div>

                </article>

            <?php endwhile;
        else :
            get_template_part( 'noresults' );
        endif;
        ?>

    </section>
</main>

<style>
/* Safe embed container */
.safe-embed-container iframe,
.safe-embed-container video,
.safe-embed-container embed,
.safe-embed-container object {
    width: 100% !important;
    max-width: 100% !important;
    height: auto !important;
}

/* Prevent cropping */
.safe-embed-container {
    width: 100%;
    overflow: visible;
}

/* Optional: code styling */
.safe-embed-container pre,
.safe-embed-container code {
    background: #1a1a2e;
    color: #fff;
    padding: 0.5rem;
    overflow-x: auto;
    border-radius: 5px;
    display: block;
}

/* Mobile responsiveness */
@media (max-width: 768px) {
    .entry-header h1 {
        font-size: 2rem;
    }
}
</style>

<?php get_sidebar(); ?>
<?php get_footer(); ?>