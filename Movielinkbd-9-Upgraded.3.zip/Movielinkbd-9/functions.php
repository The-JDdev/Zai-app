<?php
/**
 * MovieLinkBD functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package MovieLinkBD.Com
 * Author: 9xfreak.com
 * @since MovieLinkBD 1.0
 */

/*=====================
DEFINE FILE FOLDER ROOT
=======================*/
define( 'Movielinkbd_ROOT', get_template_directory() );
define( 'Movielinkbd_ROOT_URI', get_template_directory_uri() );
define( 'Movielinkbd_ROOT_PLUGINS', Movielinkbd_ROOT_URI .'/plugins' );

/*=============================================
Theme Version And Stylesheet And Jquery Connect
===============================================*/
$MovieLinkBD_theme_version = 2.0;
function theme_style_and_jquery(){	
	global $MovieLinkBD_theme_version;
	/*Style CSS*/
	wp_register_style('MovieLinkBD-css-1', get_template_directory_uri() . '/includes/css/style-1.css', array(), $MovieLinkBD_theme_version);
	wp_register_style('MovieLinkBD-css-2', get_template_directory_uri() . '/includes/css/style-2.css', array(), $MovieLinkBD_theme_version);
	wp_register_style('MovieLinkBD-css-3', get_template_directory_uri() . '/includes/css/style-3.css', array(), $MovieLinkBD_theme_version);
	wp_register_style('MovieLinkBD-css-4', get_template_directory_uri() . '/includes/css/style-4.css', array(), $MovieLinkBD_theme_version);
	wp_register_style('font-awesome-css', '//cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css?ver=6.4.2', array(), $MovieLinkBD_theme_version );
	
	/*jQuery*/
	wp_register_script( 'MovieLinkBD-js-1', get_template_directory_uri() . '/includes/jquery/jquery.js', array(), $MovieLinkBD_theme_version);

	wp_enqueue_style('MovieLinkBD-css-1');
	wp_enqueue_style('MovieLinkBD-css-2');
	wp_enqueue_style('MovieLinkBD-css-3');
	wp_enqueue_style('MovieLinkBD-css-4');
	wp_enqueue_style('font-awesome-css');
	wp_register_style('movielinkbd-upgraded', get_template_directory_uri() . '/style.css', array(), $MovieLinkBD_theme_version);
	wp_enqueue_style('movielinkbd-upgraded');

	wp_enqueue_script('MovieLinkBD-js-1');
}
add_action( 'wp_enqueue_style', 'theme_style_and_jquery');
add_action( 'wp_enqueue_scripts', 'theme_style_and_jquery');

/*====================
Custom login page logo
======================*/
function custom_login_logo() {
	echo '<style type="text/css">body{background-image: url('.get_bloginfo('template_directory').'/images/background/login-bg.png) !important;background-size: cover;background-position: center;background-repeat: no-repeat;}h1 a { background-image: url('.get_bloginfo('template_directory').'/images/logo.png) !important; background-size: 80% auto !important;
width: 90% !important;margin: 25px auto 25px !important;}.login form{background: #00000045 !important;color: #fff;}.login #login_error{background: #0176e821;border-left-color: #ff0000 !important;color: #000;}.wp-core-ui .button.button-large{background:#ff3f0d !important;clear: both;width: 100%;margin: 10px 0 0 !important;}.login a{color: #ffffff !important;}</style>'; 
}
add_action('login_head','custom_login_logo');

function my_login_logo_url() {
    return home_url();
}
add_filter( 'login_headerurl', 'my_login_logo_url' );

function my_login_logo_url_title() {
    return 'Login Logo';
}
add_filter( 'login_headertext', 'my_login_logo_url_title' );

/*===============
Admin Bar Control
=================*/

add_filter( 'show_admin_bar', '__return_false' , 1000 );

function remove_footer_admin () {
	echo'<style>#wpfooter{background:#000000;color:#ffffff;padding:10px;}#wpfooter a{text-decoration:none;color:#008dff;}</style>';
	echo 'Power by <a href="http://www.wordpress.org" target="_blank">WordPress</a> | Designed by <a href="https://9xfreak.com/" target="_blank">9xfreak.com</a></p>';
}
add_filter('admin_footer_text', 'remove_footer_admin');

/*===============
Thumbnail Support
================*/
function theme_add_thumbnail_support() {
    /**
     * Add thumbnails only to post and page post type
     * */
    add_theme_support( 'post-thumbnails', array('post', 'page') );
}
add_action( 'after_setup_theme', 'theme_add_thumbnail_support' );
add_theme_support('post-thumbnails');
add_post_type_support( 'aboutus', 'thumbnail' );

/*=================
Media Librery Call
==================*/
function enqueue_media() {
    if( function_exists( 'wp_enqueue_media' ) ) {
        wp_enqueue_media();
    }
}
add_action('admin_enqueue_scripts', 'enqueue_media');

/*=================
OpenGraph Functions
===================*/
require_once(get_template_directory() . '/opengraph/opengraph.php');

/*===============================
Languages Register Post Type Post
=================================*/
require_once(get_template_directory() . '/taxonomies/languages.php');

/*============================
Genres Register Post Type Post
==============================*/
require_once(get_template_directory() . '/taxonomies/genres.php');

/*================================
Movie Type Register Post Type Post
==================================*/
require_once(get_template_directory() . '/taxonomies/types.php');

/*=============================
Quality Register Post Type Post
===============================*/
require_once(get_template_directory() . '/taxonomies/quality.php');

/*================
Movie Metabox Call
==================*/
require_once(get_template_directory() . '/metabox/movie-metabox.php');

/*===================
Movie Required Pligin
=====================*/
if (file_exists(Movielinkbd_ROOT . '/functions/required-plugins.php')) {
	require_once( Movielinkbd_ROOT . '/functions/required-plugins.php' );
}
require_once('functions/Options.php');
require_once('functions/redux-js-css.php');


/*===================
Movie Pagination List
=====================*/
if ( !function_exists( 'movielinkbd_pagination' ) ) {
	function movielinkbd_pagination(){
		global $wp_query;
		ob_start();
		$translated = esc_html__( 'Page', 'movielinkbd' ); // Supply translatable string
		$pagination =  paginate_links( array(
		'base' => str_replace( PHP_INT_MAX, '%#%', esc_url( get_pagenum_link( PHP_INT_MAX ) ) ),
		'format' => '?paged=%#%',
		'current' => max( 1, get_query_var('paged') ),
		'total' => $wp_query->max_num_pages,
		'type' => 'array',
		'prev_text'          => __('<span></span> « Previous', 'movielinkbd'),
		'next_text'          => __('Next » <span></span>', 'movielinkbd'),
		'before_page_number' => '<span class="screen-reader-text">' . $translated . ' </span>'
		) );  
		if ( ! empty( $pagination ) ) : ?>
		<ul class="pagination justify-content-center">
		<?php foreach ( $pagination as $key => $page_link ) : ?>
		  <li class="page-item<?php if ( strpos( $page_link, 'current' ) !== false ) { echo ' active'; } ?>"><?php echo str_replace( 'page-numbers', 'page-link', $page_link ); ?></li>
		<?php endforeach ?>
		</ul>
		<?php endif;
		echo ob_get_clean();
	}
}
?>
/* ANTI-TRACKING */
remove_action('wp_head', 'wp_generator');
add_filter('the_generator', '__return_empty_string');
remove_action('wp_head', 'wlwmanifest_link');
remove_action('wp_head', 'rsd_link');
remove_action('wp_head', 'print_emoji_detection_script', 7);
remove_action('admin_print_scripts', 'print_emoji_detection_script');
remove_action('wp_print_styles', 'print_emoji_styles');
remove_action('admin_print_styles', 'print_emoji_styles');
remove_filter('the_content_feed', 'wp_staticize_emoji');
remove_filter('comment_text_rss', 'wp_staticize_emoji');
remove_filter('wp_mail', 'wp_staticize_emoji_for_email');
remove_action('wp_head', 'rest_output_link_wp_head');
remove_action('wp_head', 'wp_oembed_add_discovery_links');
remove_action('wp_head', 'wp_shortlink_wp_head');
remove_action('wp_head', 'adjacent_posts_rel_link_wp_head');
function remove_ver($src){if(strpos($src,'ver=')){$src=remove_query_arg('ver',$src);}return $src;}
add_filter('style_loader_src','remove_ver',9999);
add_filter('script_loader_src','remove_ver',9999);
add_filter('xmlrpc_enabled','__return_false');
add_filter('wp_headers',function($h){unset($h['X-Powered-By']);return $h;});
add_filter('body_class',function($c){return array_diff($c,array('wordpress','wp-theme','wp-version','logged-in','admin-bar'));});
