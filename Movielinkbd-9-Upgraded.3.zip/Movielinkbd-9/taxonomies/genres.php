<?php 
/*==================================
 * Genres Taxonomy By Post Type Post
====================================*/

/* Register taxonomy / Post Type Posts*/
function movielinkbd_genres_register() {
    // Where to register the Taxonomy > which post type
    $cpt_name = 'post';
    // Taxonomy Name
    $cpt_slug = 'genre';

    // Taxonomy Labels
    $labels = array(
        'name'                      =>  __('Genres', 'textdomain'),
        'singular_name'             =>  __('Genres', 'textdomain'),
        'search_items'              =>  __('Search Genres Movies', 'textdomain'),
        'popular_items'             =>  __('Popular Genres Movies', 'textdomain'),
        'all_items'                 =>  __('All Genres Movies', 'textdomain'),
        'parent_item'               =>  null,
        'parent_item_colon'         =>  null,
        'edit_item'                 =>  __('Edit Genres Movie', 'textdomain'),
        'update_item'               =>  __('Update Genres Movie', 'textdomain'),
        'add_new_item'              =>  __('Add New Genres Movie', 'textdomain'),
        'new_item_name'             =>  __('New Genres Movie','textdomain'),
        'separate_items_with_commas'=>  __('Separate class', 'textdomain'),
        'add_or_remove_items'       =>  __('Add or remove Genres Movie', 'textdomain'),
        'choose_from_most_used'     =>  __('Choose from most used Genres Movie', 'textdomain'),
        'not_found'                 =>  __('No Genres Movie found', 'textdomain'),
        'not_found__in_trash'       =>  __('No Genres Movie found in trash', 'textdomain'),
        'menu_name'                 =>  __('Genres', 'textdomain')
);

    // Taxonomy Args
    $args = array(
        'hierarchical'              =>  true,
        'labels'                    =>  $labels,
	'show_in_rest'              => true,
        'show_ui'                   =>  true,
        'show_admin_column'         =>  true,
       'update_count_callback'      =>  '_update_post_term_count',
       'query_var'                  =>  true,
            'rewrite'                   => array(
                'slug'  =>  $cpt_slug
        )
    );

    register_taxonomy($cpt_slug, $cpt_name, $args);
}
add_action('init', 'movielinkbd_genres_register');
?>