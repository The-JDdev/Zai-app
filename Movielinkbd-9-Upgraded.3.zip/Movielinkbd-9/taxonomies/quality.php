<?php 
/*===================================
 * Quality Taxonomy By Post Type Post
=====================================*/

/* Register taxonomy / Post Type Posts*/
function movielinkbd_quality_register() {
    // Where to register the Taxonomy > which post type
    $cpt_name = 'post';
    // Taxonomy Name
    $cpt_slug = 'quality';

    // Taxonomy Labels
    $labels = array(
        'name'                      =>  __('Quality', 'textdomain'),
        'singular_name'             =>  __('Quality', 'textdomain'),
        'search_items'              =>  __('Search Quality Movies', 'textdomain'),
        'popular_items'             =>  __('Popular Quality Movies', 'textdomain'),
        'all_items'                 =>  __('All Quality Movies', 'textdomain'),
        'parent_item'               =>  null,
        'parent_item_colon'         =>  null,
        'edit_item'                 =>  __('Edit Quality Movie', 'textdomain'),
        'update_item'               =>  __('Update Quality Movie', 'textdomain'),
        'add_new_item'              =>  __('Add New Quality Movie', 'textdomain'),
        'new_item_name'             =>  __('New Quality Movie','textdomain'),
        'separate_items_with_commas'=>  __('Separate class', 'textdomain'),
        'add_or_remove_items'       =>  __('Add or remove Quality Movie', 'textdomain'),
        'choose_from_most_used'     =>  __('Choose from most used Quality Movie', 'textdomain'),
        'not_found'                 =>  __('No Quality Movie found', 'textdomain'),
        'not_found__in_trash'       =>  __('No Quality Movie found in trash', 'textdomain'),
        'menu_name'                 =>  __('Quality', 'textdomain')
);

    // Taxonomy Args
    $args = array(
        'hierarchical'              =>  true,
        'labels'                    =>  $labels,
	'show_in_rest'              => true,
        'show_ui'                   =>  true,
        'show_admin_column'         =>  true,
       'update_count_callback'      =>  '_update_post_term_count',
       'query_var'                  =>  true,
            'rewrite'                   => array(
                'slug'  =>  $cpt_slug
        )
    );

    register_taxonomy($cpt_slug, $cpt_name, $args);
}
add_action('init', 'movielinkbd_quality_register');
?>