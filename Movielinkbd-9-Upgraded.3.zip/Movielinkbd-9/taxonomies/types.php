<?php 
/*======================================
 * Movie Type Taxonomy By Post Type Post
========================================*/

/* Register taxonomy / Post Type Posts*/
function movielinkbd_types_register() {
    // Where to register the Taxonomy > which post type
    $cpt_name = 'post';
    // Taxonomy Name
    $cpt_slug = 'movie-type';

    // Taxonomy Labels
    $labels = array(
        'name'                      =>  __('Types', 'textdomain'),
        'singular_name'             =>  __('Types', 'textdomain'),
        'search_items'              =>  __('Search Types Movies', 'textdomain'),
        'popular_items'             =>  __('Popular Types Movies', 'textdomain'),
        'all_items'                 =>  __('All Type Movies', 'textdomain'),
        'parent_item'               =>  null,
        'parent_item_colon'         =>  null,
        'edit_item'                 =>  __('Edit Types Movie', 'textdomain'),
        'update_item'               =>  __('Update Types Movie', 'textdomain'),
        'add_new_item'              =>  __('Add New Types Movie', 'textdomain'),
        'new_item_name'             =>  __('New Types Movie','textdomain'),
        'separate_items_with_commas'=>  __('Separate class', 'textdomain'),
        'add_or_remove_items'       =>  __('Add or remove Types Movie', 'textdomain'),
        'choose_from_most_used'     =>  __('Choose from most used Type Movie', 'textdomain'),
        'not_found'                 =>  __('No Types Movie found', 'textdomain'),
        'not_found__in_trash'       =>  __('No Types Movie found in trash', 'textdomain'),
        'menu_name'                 =>  __('Movie Types', 'textdomain')
);

    // Taxonomy Args
    $args = array(
        'hierarchical'              =>  true,
        'labels'                    =>  $labels,
	'show_in_rest'              => true,
        'show_ui'                   =>  true,
        'show_admin_column'         =>  true,
       'update_count_callback'      =>  '_update_post_term_count',
       'query_var'                  =>  true,
            'rewrite'                   => array(
                'slug'  =>  $cpt_slug
        )
    );

    register_taxonomy($cpt_slug, $cpt_name, $args);
}
add_action('init', 'movielinkbd_types_register');
?>