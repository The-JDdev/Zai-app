<style>
/* Glitch Effect for No Results */
.no-results-glitch {
    font-size: 2.5rem;
    font-weight: bold;
    text-transform: uppercase;
    position: relative;
    text-shadow: 0.05em 0 0 #ff0000, -0.03em -0.04em 0 #00ff00,
                 0.025em 0.04em 0 #0000ff;
    animation: noresults-glitch 725ms infinite;
    color: #fff;
    margin: 20px 0;
}

.no-results-glitch span {
    position: absolute;
    top: 0;
    left: 0;
}

.no-results-glitch span:first-child {
    animation: noresults-glitch 500ms infinite;
    clip-path: polygon(0 0, 100% 0, 100% 35%, 0 35%);
    transform: translate(-0.04em, -0.03em);
    opacity: 0.75;
}

.no-results-glitch span:last-child {
    animation: noresults-glitch 375ms infinite;
    clip-path: polygon(0 65%, 100% 65%, 100% 100%, 0 100%);
    transform: translate(0.04em, 0.03em);
    opacity: 0.75;
}

@keyframes noresults-glitch {
    0% {
        text-shadow: 0.05em 0 0 #ff0000, -0.03em -0.04em 0 #00ff00,
                     0.025em 0.04em 0 #0000ff;
    }
    15% {
        text-shadow: 0.05em 0 0 #ff0000, -0.03em -0.04em 0 #00ff00,
                     0.025em 0.04em 0 #0000ff;
    }
    16% {
        text-shadow: -0.05em -0.025em 0 #ff0000, 0.025em 0.035em 0 #00ff00,
                     -0.05em -0.05em 0 #0000ff;
    }
    49% {
        text-shadow: -0.05em -0.025em 0 #ff0000, 0.025em 0.035em 0 #00ff00,
                     -0.05em -0.05em 0 #0000ff;
    }
    50% {
        text-shadow: 0.05em 0.035em 0 #ff0000, 0.03em 0 0 #00ff00,
                     0 -0.04em 0 #0000ff;
    }
    99% {
        text-shadow: 0.05em 0.035em 0 #ff0000, 0.03em 0 0 #00ff00,
                     0 -0.04em 0 #0000ff;
    }
    100% {
        text-shadow: -0.05em 0 0 #ff0000, -0.025em -0.04em 0 #00ff00,
                     -0.04em -0.025em 0 #0000ff;
    }
}

.no-results-content {
    background: rgba(255,0,0,0.1);
    padding: 30px 20px;
    border-radius: 10px;
    margin: 20px;
    text-align: center;
    border: 2px solid #ff4444;
}

.suggestion-list {
    text-align: left;
    display: inline-block;
    margin: 15px 0;
}

.suggestion-list li {
    margin: 8px 0;
    color: #fff;
}

.search-tips {
    background: rgba(255,215,0,0.1);
    padding: 15px;
    border-radius: 8px;
    margin: 15px 0;
    border-left: 4px solid #FFD700;
}

.trending-movies {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
    gap: 10px;
    margin-top: 20px;
}

.trending-item {
    text-align: center;
}

.trending-item img {
    width: 100%;
    height: 150px;
    object-fit: cover;
    border-radius: 8px;
}

.trending-title {
    font-size: 11px;
    color: #fff;
    margin-top: 5px;
    font-weight: bold;
}
</style>

<div class="text-center" itemscope itemtype="https://schema.org/SearchResultsPage">
    <!-- Glitch Effect for No Results -->
    <div class="no-results-glitch" data-text="NO RESULTS FOUND">NO RESULTS FOUND<span aria-hidden="true">NO RESULTS FOUND</span><span aria-hidden="true">NO RESULTS FOUND</span></div>
    
    <div class="no-results-content">
        <h3 style="color: #ff6b6b; margin-bottom: 15px;">
            <i class="fas fa-search"></i> Search Came Up Empty!
        </h3>
        
        <p style="color: #fff; margin-bottom: 20px;">
            <strong>We couldn't find any movies matching "<span style="color: #87CEEB;"><?php echo get_search_query(); ?></span>"</strong>
        </p>

        <div class="search-tips">
            <h4 style="color: #FFD700; margin-bottom: 10px;">
                <i class="fas fa-lightbulb"></i> Search Tips:
            </h4>
            <ul class="suggestion-list">
                <li>🔍 <strong>Check your spelling</strong> - Try different variations</li>
                <li>🎬 <strong>Use the movie's original name</strong> - Avoid translations</li>
                <li>📅 <strong>Search by year</strong> - Example: "Movie Name 2024"</li>
                <li>🌟 <strong>Try partial names</strong> - Use shorter keywords</li>
            </ul>
        </div>

        <p style="color: #32CD32; margin: 20px 0;">
            <i class="fas fa-arrow-down"></i> 
            <strong>Check out these trending movies instead:</strong>
        </p>
    </div>

    <!-- Trending Movies Section -->
    <div class="trending-movies">
    <?php 
    // Show trending movies as fallback
    $trending_movies = new WP_Query(array(
        'post_type' => 'post',
        'posts_per_page' => 6,
        'meta_key' => 'custom-field-5',
        'meta_value' => 'Trending',
        'no_found_rows' => true,
        'update_post_term_cache' => false,
        'update_post_meta_cache' => false
    ));
    
    if ($trending_movies->have_posts()) {
        while ($trending_movies->have_posts()) {
            $trending_movies->the_post();
            
            $thumbnail = get_the_post_thumbnail_url() ?: get_template_directory_uri().'/images/no-image.png';
            $title = get_the_title();
            ?>
            <div class="trending-item">
                <a href="<?php the_permalink(); ?>" title="<?php echo esc_attr($title); ?>">
                    <img src="<?php echo esc_url($thumbnail); ?>" 
                         alt="<?php echo esc_attr($title); ?>" 
                         loading="lazy"
                         width="120" 
                         height="150">
                    <div class="trending-title"><?php echo esc_html($title); ?></div>
                </a>
            </div>
            <?php
        }
        wp_reset_postdata();
    } else {
        // Fallback to recent posts if no trending found
        $recent_fallback = new WP_Query(array(
            'post_type' => 'post',
            'posts_per_page' => 6,
            'orderby' => 'date',
            'order' => 'DESC',
            'no_found_rows' => true
        ));
        
        while ($recent_fallback->have_posts()) {
            $recent_fallback->the_post();
            
            $thumbnail = get_the_post_thumbnail_url() ?: get_template_directory_uri().'/images/no-image.png';
            $title = get_the_title();
            ?>
            <div class="trending-item">
                <a href="<?php the_permalink(); ?>" title="<?php echo esc_attr($title); ?>">
                    <img src="<?php echo esc_url($thumbnail); ?>" 
                         alt="<?php echo esc_attr($title); ?>" 
                         loading="lazy"
                         width="120" 
                         height="150">
                    <div class="trending-title"><?php echo esc_html($title); ?></div>
                </a>
            </div>
            <?php
        }
        wp_reset_postdata();
    }
    ?>
    </div>

    <!-- Try Again Search -->
    <div style="margin: 25px 20px;">
        <p style="color: #fff; margin-bottom: 15px;">
            <strong>Want to try another search?</strong>
        </p>
        <div style="max-width: 350px; margin: 0 auto;">
            <?php 
            // Custom search form
            get_search_form(); 
            ?>
        </div>
    </div>
</div>