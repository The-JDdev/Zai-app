<?php
/**
 * MovieLinkBD Search and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package MovieLinkBD.Com
 * Author: 9xfreak.com
 * @since MovieLinkBD 1.0
 */
get_header();
?>

<div class="text-md border-bottom-success text-center align-items-center text-success font-weight-bold" style="user-select: none">
	<br/>
	<h2 class="text-md text-success"> Result : <?php the_search_query(); ?> </h2>
</div>

<div class="movie-cards-container" style="display: flex; flex-wrap: wrap;">
<?php
$i = 1; if (have_posts()) : while (have_posts()) : the_post();
$Rating = get_post_meta($post->ID, 'custom-field-2', true)?: '0.0';
?>

<div class="movie-card">
        <div class="image-container">
            <a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" class="title">
		<?php
		$loaderimage = get_template_directory_uri()."/images/loader/movielinkbd_load.svg";
		$thumbnail = get_the_post_thumbnail_url();
		$nothumbnail = get_template_directory_uri()."/images/no-image.png";
		if ( has_post_thumbnail() ) {
		echo '<img src="'.$loaderimage.'" data-src="'.$thumbnail.'"'.' alt="'.get_the_title().'"'.' loading="b-lazy"'.' class="lazy"/>';
		} else {
		echo '<img src="'.$loaderimage.'" data-src="'.$nothumbnail.'"'.' alt="'.get_the_title().'"'.' loading="b-lazy"'.' class="lazy"/>';
		} ?>
            </a>
		<?php
		echo '<span class="rating">'.$Rating.'</span>';
		?>
		
		<?php 
		echo'<span class="quality">';
		echo strip_tags(get_the_term_list( $post->ID, 'quality', ' ',', '));
		echo '</span>';
		?>
                
		<?php 
		echo'<span class="language">';
		echo strip_tags(get_the_term_list( $post->ID, 'language', ' ',', '));
		echo '</span>';
		?>

		<?php 
		echo'<span class="type">';
		echo strip_tags(get_the_term_list( $post->ID, 'movie-type', ' ',', '));
		echo '</span>';
		?>

        </div>
        <div class="content">
            <a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" class="title"><?php the_title(); ?></a>
        </div>
</div>

<?php endwhile;
else : get_template_part('/templates/no-results');
endif; ?>
</div>

<br/>
<nav aria-label="Page navigation">
	<?php movielinkbd_pagination();?>
</nav>
<br/>

<?php get_template_part('/templates/posts/more-downloads');?>
<?php get_footer();?>