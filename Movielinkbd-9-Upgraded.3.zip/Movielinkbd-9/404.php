<?php
/**
 * Keyword Error Page
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package Boimate.Com
 * @since Boimate 1.0
 */
get_header();
?>

<?php get_footer();?>