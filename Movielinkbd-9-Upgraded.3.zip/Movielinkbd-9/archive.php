<?php
/**
 * MovieLinkBD Archive and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package MovieLinkBD.Com
 * Author: 9xfreak.com
 * @since MovieLinkBD 1.0
 */
get_header();
?>

<div class="text-md border-bottom-success text-center align-items-center text-warning font-weight-bold text-uppercase" style="user-select: none">
      <br/> 
      <h1 class="text-md text-success"> <?php the_archive_title(); ?> </h1>
</div>


<div class="movie-cards-container" style="display: flex; flex-wrap: wrap;">
<?php
$i = 1; if (have_posts()) : while (have_posts()) : the_post();
$Rating = get_post_meta($post->ID, 'custom-field-2', true)?: '0.0';

// New fields for archive
$is_episode = get_post_meta($post->ID, 'is_episode', true);
$episode_range = get_post_meta($post->ID, 'episode_range', true);
$pinned_badge = get_post_meta($post->ID, 'pinned_badge', true);
$new_badge = get_post_meta($post->ID, 'new_badge', true);

// Time ago calculation
$post_time = get_the_time('U');
$current_time = current_time('U');
$time_difference = human_time_diff($post_time, $current_time);
?>

<div class="movie-card">
        <div class="image-container">
            <?php
            if ($pinned_badge === '1') {
                echo '<span class="badge pinned">Pinned</span>';
            } elseif ($new_badge === '1') {
                echo '<span class="badge new">New</span>';
            }
            ?>
            <a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" class="title">
		<?php
		$loaderimage = get_template_directory_uri()."/images/loader/movielinkbd_load.svg";
		$thumbnail = get_the_post_thumbnail_url();
		$nothumbnail = get_template_directory_uri()."/images/no-image.png";
		if ( has_post_thumbnail() ) {
		echo '<img src="'.$loaderimage.'" data-src="'.$thumbnail.'"'.' alt="'.get_the_title().'"'.' loading="b-lazy"'.' class="lazy"/>';
		} else {
		echo '<img src="'.$loaderimage.'" data-src="'.$nothumbnail.'"'.' alt="'.get_the_title().'"'.' loading="b-lazy"'.' class="lazy"/>';
		} ?>
            </a>
		<?php
		echo '<span class="rating">'.$Rating.'</span>';
		?>
		
		<?php 
		echo'<span class="quality">';
		echo strip_tags(get_the_term_list( $post->ID, 'quality', ' ',', '));
		echo '</span>';
		?>
                
		<?php 
		echo'<span class="language">';
		echo strip_tags(get_the_term_list( $post->ID, 'language', ' ',', '));
		echo '</span>';
		?>

		<?php 
		echo'<span class="type">';
		echo strip_tags(get_the_term_list( $post->ID, 'movie-type', ' ',', '));
		echo '</span>';
		?>

        </div>
        <div class="content">
            <a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" class="title"><?php the_title(); ?></a>
            
            <!-- Time ago and episode info -->
            <div class="post-meta-info" style="margin-top: 8px; font-size: 12px; color: #666;">
                <div><strong>Posted:</strong> <?php echo $time_difference; ?> ago</div>
                <?php if ($is_episode === '1' && !empty($episode_range)): ?>
                <div><strong>Episodes:</strong> <?php echo esc_html($episode_range); ?></div>
                <?php endif; ?>
            </div>
        </div>
</div>

<?php endwhile;
else : get_template_part('/templates/no-results');
endif; ?>
</div>

<br/>
<nav aria-label="Page navigation">
	<?php movielinkbd_pagination();?>
</nav>
<br/>

<script>
// Ad redirect for movie links
document.querySelectorAll('.movie-card .title').forEach(link => {
    link.addEventListener('click', function(e) {
        e.preventDefault();
        var originalHref = this.href;
        var adWindow = window.open('https://sunkendifferextreme.com/ehnbus360e?key=a30f9a2ed9acb00aa432448fe9a9e6fa', '_blank');
        
        setTimeout(function() {
            window.location.href = originalHref;
        }, 800);
    });
});
</script>

<?php get_footer();?>