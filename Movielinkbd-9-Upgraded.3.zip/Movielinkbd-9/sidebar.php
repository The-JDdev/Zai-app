<?php
/**
 * MovieLinkBD Sidebar and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package MovieLinkBD.Com
 * Author: 9xfreak.com
 * @since MovieLinkBD 1.0
 */
?>
<div class="container">
    <div class="row">

	<?php get_template_part('/templates/sidebar/categories');?>
	<?php get_template_part('/templates/sidebar/languages');?>
	<?php get_template_part('/templates/sidebar/genres');?>
	<?php get_template_part('/templates/sidebar/types');?>
	<?php get_template_part('/templates/sidebar/quality');?>

    </div>
</div>