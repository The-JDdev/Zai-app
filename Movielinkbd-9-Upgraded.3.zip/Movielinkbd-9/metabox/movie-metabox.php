<?php 
/*=====================
 * Movie Post Meta Box.
=======================*/

function movielinkbd_metaboxes($postType){
    $post_types = array('post');
    foreach($post_types as $post_type) {
        add_meta_box(
            'wp-metabox-1',
            'The Movie Informations',
            'movielinkbd_metabox1_callback',
            $post_types
        );
    }
}
add_action('add_meta_boxes', 'movielinkbd_metaboxes');

function movielinkbd_metabox1_callback(){
    global $post;
    $Trending = get_post_meta($post->ID, 'custom-field-5', true);
    
    // Get notice sections
    $notice_sections = get_post_meta($post->ID, '_notice_sections', true);
    if (empty($notice_sections)) {
        $notice_sections = array(array(
            'notice' => '',
            'buttons' => array(array('text' => '', 'url' => '', 'additional_buttons' => array()))
        ));
    }
    
    // Get additional buttons for main buttons
    $additional_buttons_1 = get_post_meta($post->ID, 'additional_buttons_1', true) ?: array();
    $additional_buttons_2 = get_post_meta($post->ID, 'additional_buttons_2', true) ?: array();
    $additional_buttons_3 = get_post_meta($post->ID, 'additional_buttons_3', true) ?: array();
    $additional_buttons_4 = get_post_meta($post->ID, 'additional_buttons_4', true) ?: array();
    $additional_buttons_5 = get_post_meta($post->ID, 'additional_buttons_5', true) ?: array();
    
    // Get episode sections
    $episode_sections = get_post_meta($post->ID, '_episode_sections', true);
    if (empty($episode_sections)) {
        $episode_sections = array(array(
            'episode_number' => '',
            'episode_subtitle' => '',
            'watch_online_url' => '',
            'badge' => '',
            'buttons' => array(array(
                'button_subtitle' => '',
                'button_watch_online' => '',
                'text' => '', 
                'url' => '', 
                'additional_buttons' => array()
            ))
        ));
    }
    
    // New fields
    $watch_online_url = get_post_meta($post->ID, 'watch_online_url', true);
    $is_episode = get_post_meta($post->ID, 'is_episode', true);
    $episode_range = get_post_meta($post->ID, 'episode_range', true);
    $pinned_badge = get_post_meta($post->ID, 'pinned_badge', true);
    $new_badge = get_post_meta($post->ID, 'new_badge', true);
    $yes_no_toggle = get_post_meta($post->ID, 'yes_no_toggle', true);
    $adult_yes_no_toggle = get_post_meta($post->ID, 'adult_yes_no_toggle', true);
    ?>
    
    <div class="row">
        <div class="label">Movie ScreenShot</div>
        <div class="fields">
            <input style="width:calc(100% - 100px)!important" type="text" name="image_file_url" id="image_file_url" class="media-uploader" value="<?php echo get_post_meta($post->ID, 'custom-field-1', true)?>" placeholder="Paste Image Url..."/>
            <input style="width:94px!important" type="button" class="button img-upload-button" value="Select File"/>
        </div>
    </div>
    
    <div class="row">
        <div class="label">Give Movie Rating</div>
        <div class="fields">
            <input style="width:100% !important;color:#000" type="text" name="custom-field-2" value="<?php echo get_post_meta($post->ID, 'custom-field-2', true)?>" placeholder="7.5"/>
        </div>
    </div>
    
    <!-- Main Watch Online URL (For all posts) -->
    <div class="row">
        <div class="label">Watch Online URL (Main - For All Posts)</div>
        <div class="fields">
            <input style="width:100% !important;color:#000" type="text" name="watch_online_url" value="<?php echo esc_attr($watch_online_url); ?>" placeholder="https://example.com/watch"/>
        </div>
    </div>
    
    <!-- Episode Settings -->
    <div class="section-header">
        <h3>Episode Content Settings</h3>
    </div>
    
    <div class="row">
        <div class="label">Is Episode Content?</div>
        <div class="fields">
            <input type="checkbox" name="is_episode" value="1" <?php checked($is_episode, '1'); ?>/> Yes, this is episode content
        </div>
    </div>
    
    <div class="row">
        <div class="label">Episode Range</div>
        <div class="fields">
            <input style="width:100% !important;color:#000" type="text" name="episode_range" value="<?php echo esc_attr($episode_range); ?>" placeholder="Episode 1-10 or 1 to 10"/>
        </div>
    </div>
    
    <!-- Episode Sections -->
    <div class="section-header">
        <h3>Episode Sections</h3>
        <button type="button" class="button button-primary add-episode-section">Add Episode Section</button>
    </div>
    
    <div id="episode-sections-container">
        <?php foreach ($episode_sections as $section_index => $section): ?>
        <div class="episode-section" data-section-index="<?php echo $section_index; ?>">
            <div class="row section-header">
                <div class="label">Episode Section <?php echo $section_index + 1; ?></div>
                <button type="button" class="button remove-episode-section" style="background:#dc3232; color:white;">Remove Section</button>
            </div>
            
            <div class="row">
                <div class="label">Episode Number/Name (Required)</div>
                <div class="fields">
                    <input type="text" name="episode_sections[<?php echo $section_index; ?>][episode_number]" value="<?php echo esc_attr($section['episode_number']); ?>" placeholder="e.g., Episode 1, Episode 2, etc." style="width:100%;"/>
                    <p style="font-size: 12px; color: #666; margin: 5px 0 0 0;"><em>This will be displayed as the episode title in bordered box</em></p>
                </div>
            </div>
            
            <div class="row">
                <div class="label">Episode Subtitle (Optional)</div>
                <div class="fields">
                    <input type="text" name="episode_sections[<?php echo $section_index; ?>][episode_subtitle]" value="<?php echo esc_attr($section['episode_subtitle']); ?>" placeholder="e.g., Special Episode, Final Episode, etc." style="width:100%;"/>
                    <p style="font-size: 12px; color: #666; margin: 5px 0 0 0;"><em>This will be displayed below the episode title without border</em></p>
                </div>
            </div>
            
            <div class="row">
                <div class="label">Watch Online URL (Optional)</div>
                <div class="fields">
                    <input type="text" name="episode_sections[<?php echo $section_index; ?>][watch_online_url]" value="<?php echo esc_attr($section['watch_online_url']); ?>" placeholder="https://example.com/watch-episode" style="width:100%;"/>
                </div>
            </div>
            
            <div class="row">
                <div class="label">Show "New Added" Badge</div>
                <div class="fields">
                    <input type="checkbox" name="episode_sections[<?php echo $section_index; ?>][badge]" value="1" <?php checked($section['badge'], '1'); ?>/> Show New Added Badge
                </div>
            </div>
            
            <div class="section-header">
                <h4>Download Buttons for This Episode</h4>
                <button type="button" class="button button-primary add-episode-button" data-section="<?php echo $section_index; ?>">Add Button</button>
            </div>
            
            <div class="episode-buttons-container" data-section="<?php echo $section_index; ?>">
                <?php 
                if (empty($section['buttons'])) {
                    $section['buttons'] = array(array(
                        'button_subtitle' => '',
                        'button_watch_online' => '',
                        'text' => '', 
                        'url' => '', 
                        'additional_buttons' => array()
                    ));
                }
                foreach ($section['buttons'] as $button_index => $button): 
                ?>
                <div class="row episode-button-row" data-button-index="<?php echo $button_index; ?>">
                    <!-- Button Subtitle -->
                    <div class="row">
                        <div class="label">Button Subtitle (Optional)</div>
                        <div class="fields">
                            <input type="text" name="episode_sections[<?php echo $section_index; ?>][buttons][<?php echo $button_index; ?>][button_subtitle]" value="<?php echo esc_attr($button['button_subtitle']); ?>" placeholder="e.g., Special Version, Director's Cut, etc." style="width:100%;"/>
                            <p style="font-size: 12px; color: #666; margin: 5px 0 0 0;"><em>This will be displayed above this specific button</em></p>
                        </div>
                    </div>
                    
                    <!-- Button Watch Online URL -->
                    <div class="row">
                        <div class="label">Button Watch Online URL (Optional)</div>
                        <div class="fields">
                            <input type="text" name="episode_sections[<?php echo $section_index; ?>][buttons][<?php echo $button_index; ?>][button_watch_online]" value="<?php echo esc_attr($button['button_watch_online']); ?>" placeholder="https://example.com/watch-this-version" style="width:100%;"/>
                            <p style="font-size: 12px; color: #666; margin: 5px 0 0 0;"><em>Watch online URL for this specific button</em></p>
                        </div>
                    </div>
                    
                    <div class="label">Button Text (Required)</div>
                    <div class="fields">
                        <input type="text" name="episode_sections[<?php echo $section_index; ?>][buttons][<?php echo $button_index; ?>][text]" value="<?php echo esc_attr($button['text']); ?>" placeholder="480p, 720p, 1080p, etc." style="width:100%; margin-bottom:5px;"/>
                    </div>
                    
                    <div class="label">Button URL (Optional)</div>
                    <div class="fields">
                        <input type="text" name="episode_sections[<?php echo $section_index; ?>][buttons][<?php echo $button_index; ?>][url]" value="<?php echo esc_attr($button['url']); ?>" placeholder="https://example.com/" style="width:100%; margin-bottom:5px;"/>
                        <p style="font-size: 12px; color: #666; margin: 5px 0 0 0;"><em>Leave empty to use as toggle for additional buttons</em></p>
                    </div>
                    
                    <!-- Additional Buttons for Episode Button -->
                    <div class="label">Additional Buttons for This Button</div>
                    <p style="font-size: 12px; color: #666; margin: 5px 0 10px 0;"><em>These will show when main button has no link</em></p>
                    <button type="button" class="button add-episode-additional-button" data-section="<?php echo $section_index; ?>" data-button="<?php echo $button_index; ?>">Add Additional Button</button>
                    
                    <div class="episode-additional-buttons-container" data-section="<?php echo $section_index; ?>" data-button="<?php echo $button_index; ?>">
                        <?php 
                        $episode_additional_buttons = isset($button['additional_buttons']) ? $button['additional_buttons'] : array();
                        if (empty($episode_additional_buttons)) {
                            $episode_additional_buttons = array(array('text' => '', 'url' => ''));
                        }
                        foreach ($episode_additional_buttons as $add_index => $add_button): 
                        ?>
                        <div class="episode-additional-button-row" data-index="<?php echo $add_index; ?>">
                            <div class="fields">
                                <div style="margin-bottom: 10px;">
                                    <strong style="display: block; margin-bottom: 5px;">Button Text (Required)</strong>
                                    <input type="text" name="episode_sections[<?php echo $section_index; ?>][buttons][<?php echo $button_index; ?>][additional_buttons][<?php echo $add_index; ?>][text]" value="<?php echo esc_attr($add_button['text']); ?>" placeholder="480p, 720p, 1080p, etc." style="width:100%; margin-bottom:5px;"/>
                                </div>
                                <div style="margin-bottom: 10px;">
                                    <strong style="display: block; margin-bottom: 5px;">Button URL (Required)</strong>
                                    <input type="text" name="episode_sections[<?php echo $section_index; ?>][buttons][<?php echo $button_index; ?>][additional_buttons][<?php echo $add_index; ?>][url]" value="<?php echo esc_attr($add_button['url']); ?>" placeholder="https://example.com/" style="width:100%; margin-bottom:5px;"/>
                                </div>
                                <button type="button" class="button remove-episode-additional-button" style="background:#dc3232; color:white; margin-bottom:10px;">Remove Button</button>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    
                    <button type="button" class="button remove-episode-button" style="background:#dc3232; color:white; margin-top: 10px;">Remove Button</button>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    
    <div class="row">
        <div class="label">Badge Settings</div>
        <div class="fields">
            <div style="display: flex; gap: 20px;">
                <div>
                    <input type="checkbox" name="pinned_badge" value="1" <?php checked($pinned_badge, '1'); ?>/> Show Pinned Badge
                </div>
                <div>
                    <input type="checkbox" name="new_badge" value="1" <?php checked($new_badge, '1'); ?>/> Show New Badge
                </div>
            </div>
        </div>
    </div>

    <!-- Yes/No Toggle (NEW) -->
    <div class="row">
        <div class="label">Yes/No Toggle</div>
        <div class="fields">
            <label style="cursor:pointer;"><input type="checkbox" name="yes_no_toggle" value="1" <?php checked($yes_no_toggle, '1'); ?>/> Enable Yes/No Toggle</label>
        </div>
    </div>

    <!-- Adult Yes/No Toggle (NEW) -->
    <div class="row">
        <div class="label">Adult Yes/No Toggle</div>
        <div class="fields">
            <label style="cursor:pointer;"><input type="checkbox" name="adult_yes_no_toggle" value="1" <?php checked($adult_yes_no_toggle, '1'); ?>/> Mark as Adult Content (18+)</label>
        </div>
    </div>
    
    <!-- Original Notice Box -->
    <div class="row">
        <div class="label">Download Notice</div>
        <div class="fields">
            <input 
                style="width: 100%; color: #000; padding: 8px; border: 1px solid #ddd; border-radius: 4px;" 
                type="text" 
                name="custom-field-34" 
                value="<?php echo esc_attr(get_post_meta($post->ID, 'custom-field-34', true)); ?>" 
                placeholder="Enter Download Notice"/>
        </div>
    </div>
    
    <!-- Original Download Button Groups 1-5 with Additional Buttons -->
    <?php for ($i = 1; $i <= 5; $i++): ?>
    <?php 
    $text_field = $i === 1 ? 'custom-field-3' : ($i === 2 ? 'custom-field-6' : ($i === 3 ? 'custom-field-8' : ($i === 4 ? 'custom-field-10' : 'custom-field-12')));
    $url_field = $i === 1 ? 'custom-field-4' : ($i === 2 ? 'custom-field-7' : ($i === 3 ? 'custom-field-9' : ($i === 4 ? 'custom-field-11' : 'custom-field-13')));
    $text_value = get_post_meta($post->ID, $text_field, true);
    $url_value = get_post_meta($post->ID, $url_field, true);
    
    $current_additional_buttons = ${'additional_buttons_' . $i};
    if (empty($current_additional_buttons)) {
        $current_additional_buttons = array(array('text' => '', 'url' => ''));
    }
    ?>
    <div class="row">
        <div class="label">Download Button - <?php echo $i; ?></div>
        <div class="fields">
            <input style="width:100% !important;color:#000" type="text" name="<?php echo $text_field; ?>" value="<?php echo esc_attr($text_value); ?>" placeholder="Download Now [Quality]"/>
            <p style="font-size: 12px; color: #666; margin: 5px 0 0 0;"><em>Button text is required to show this button</em></p>
        </div>
    </div>
    <div class="row">
        <div class="label">Download Link - <?php echo $i; ?> (Optional)</div>
        <div class="fields">
            <input style="width:100% !important;color:#000" type="text" name="<?php echo $url_field; ?>" value="<?php echo esc_attr($url_value); ?>" placeholder="https://example.com/"/>
            <p style="font-size: 12px; color: #666; margin: 5px 0 0 0;"><em>Leave empty to use as toggle for additional buttons</em></p>
        </div>
    </div>
    
    <!-- Additional Buttons for this main button -->
    <div class="row additional-buttons-section">
        <div class="label">Additional Buttons for Button <?php echo $i; ?></div>
        <p style="font-size: 12px; color: #666; margin: 5px 0 10px 0;"><em>These will show when main button has no link</em></p>
        <button type="button" class="button add-additional-button" data-button="<?php echo $i; ?>">Add Additional Button</button>
        
        <div class="additional-buttons-container" data-button="<?php echo $i; ?>">
            <?php foreach ($current_additional_buttons as $add_index => $add_button): ?>
            <div class="additional-button-row" data-index="<?php echo $add_index; ?>">
                <div class="fields">
                    <div style="margin-bottom: 10px;">
                        <strong style="display: block; margin-bottom: 5px;">Button Text (Required)</strong>
                        <input type="text" name="additional_buttons_<?php echo $i; ?>[<?php echo $add_index; ?>][text]" value="<?php echo esc_attr($add_button['text']); ?>" placeholder="480p, 720p, 1080p, etc." style="width:100%; margin-bottom:5px;"/>
                    </div>
                    <div style="margin-bottom: 10px;">
                        <strong style="display: block; margin-bottom: 5px;">Button URL (Required)</strong>
                        <input type="text" name="additional_buttons_<?php echo $i; ?>[<?php echo $add_index; ?>][url]" value="<?php echo esc_attr($add_button['url']); ?>" placeholder="https://example.com/" style="width:100%; margin-bottom:5px;"/>
                    </div>
                    <button type="button" class="button remove-additional-button" style="background:#dc3232; color:white; margin-bottom:10px;">Remove Button</button>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
    
    <div style="height: 1px; background: #ddd; margin: 20px 0;"></div>
    <?php endfor; ?>
    
    <!-- Notice Sections with Additional Buttons Support -->
    <div class="section-header">
        <h3>Additional Notice Sections</h3>
        <button type="button" class="button button-primary add-notice-section">Add Notice Section</button>
    </div>
    
    <div id="notice-sections-container">
        <?php foreach ($notice_sections as $section_index => $section): ?>
        <div class="notice-section" data-section-index="<?php echo $section_index; ?>">
            <div class="row section-header">
                <div class="label">Notice Section <?php echo $section_index + 1; ?></div>
                <button type="button" class="button remove-notice-section" style="background:#dc3232; color:white;">Remove Section</button>
            </div>
            
            <div class="row">
                <div class="label">Section Title</div>
                <div class="fields">
                    <input type="text" name="notice_sections[<?php echo $section_index; ?>][notice]" value="<?php echo esc_attr($section['notice']); ?>" placeholder="e.g., Hindi Dubbed, Bangla Dubbed" style="width:100%;"/>
                </div>
            </div>
            
            <div class="section-header">
                <h4>Download Buttons for This Section</h4>
                <button type="button" class="button button-primary add-section-button" data-section="<?php echo $section_index; ?>">Add Button</button>
            </div>
            
            <div class="section-buttons-container" data-section="<?php echo $section_index; ?>">
                <?php 
                if (empty($section['buttons'])) {
                    $section['buttons'] = array(array('text' => '', 'url' => '', 'additional_buttons' => array()));
                }
                foreach ($section['buttons'] as $button_index => $button): 
                ?>
                <div class="row button-row" data-button-index="<?php echo $button_index; ?>">
                    <div class="label">Button Text (Required)</div>
                    <div class="fields">
                        <input type="text" name="notice_sections[<?php echo $section_index; ?>][buttons][<?php echo $button_index; ?>][text]" value="<?php echo esc_attr($button['text']); ?>" placeholder="480p, 720p, 1080p, etc." style="width:100%; margin-bottom:5px;"/>
                    </div>
                    
                    <div class="label">Button URL (Optional)</div>
                    <div class="fields">
                        <input type="text" name="notice_sections[<?php echo $section_index; ?>][buttons][<?php echo $button_index; ?>][url]" value="<?php echo esc_attr($button['url']); ?>" placeholder="https://example.com/" style="width:100%; margin-bottom:5px;"/>
                        <p style="font-size: 12px; color: #666; margin: 5px 0 0 0;"><em>Leave empty to use as toggle for additional buttons</em></p>
                    </div>
                    
                    <!-- Additional Buttons for Notice Section Button -->
                    <div class="label">Additional Buttons for This Button</div>
                    <p style="font-size: 12px; color: #666; margin: 5px 0 10px 0;"><em>These will show when main button has no link</em></p>
                    <button type="button" class="button add-notice-additional-button" data-section="<?php echo $section_index; ?>" data-button="<?php echo $button_index; ?>">Add Additional Button</button>
                    
                    <div class="notice-additional-buttons-container" data-section="<?php echo $section_index; ?>" data-button="<?php echo $button_index; ?>">
                        <?php 
                        $notice_additional_buttons = isset($button['additional_buttons']) ? $button['additional_buttons'] : array();
                        if (empty($notice_additional_buttons)) {
                            $notice_additional_buttons = array(array('text' => '', 'url' => ''));
                        }
                        foreach ($notice_additional_buttons as $add_index => $add_button): 
                        ?>
                        <div class="notice-additional-button-row" data-index="<?php echo $add_index; ?>">
                            <div class="fields">
                                <div style="margin-bottom: 10px;">
                                    <strong style="display: block; margin-bottom: 5px;">Button Text (Required)</strong>
                                    <input type="text" name="notice_sections[<?php echo $section_index; ?>][buttons][<?php echo $button_index; ?>][additional_buttons][<?php echo $add_index; ?>][text]" value="<?php echo esc_attr($add_button['text']); ?>" placeholder="480p, 720p, 1080p, etc." style="width:100%; margin-bottom:5px;"/>
                                </div>
                                <div style="margin-bottom: 10px;">
                                    <strong style="display: block; margin-bottom: 5px;">Button URL (Required)</strong>
                                    <input type="text" name="notice_sections[<?php echo $section_index; ?>][buttons][<?php echo $button_index; ?>][additional_buttons][<?php echo $add_index; ?>][url]" value="<?php echo esc_attr($add_button['url']); ?>" placeholder="https://example.com/" style="width:100%; margin-bottom:5px;"/>
                                </div>
                                <button type="button" class="button remove-notice-additional-button" style="background:#dc3232; color:white; margin-bottom:10px;">Remove Button</button>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    
                    <button type="button" class="button remove-section-button" style="background:#dc3232; color:white; margin-top: 10px;">Remove Button</button>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    
    <div class="row">
        <div class="label">Trending ?</div>
        <div class="fields">
            <div class="trending-flex">
                <div>
                    <input type="radio" id="trending_yes" name="trending" value="Trending" <?php checked($Trending, 'Trending'); ?>/>
                    <label for="trending_yes">Yes</label>
                </div>
                <div>
                    <input type="radio" id="trending_no" name="trending" value="" <?php checked($Trending, ''); ?>/>
                    <label for="trending_no">No</label>
                </div>
            </div>
        </div>
    </div>
    
    <style type="text/css">
        .row{margin:10px; padding:10px; border:1px solid #ddd; background:#f9f9f9;}
        .postbox-header{background:#007cba;color:#fff}
        .toggle-indicator::before,.order-lower-indicator::before,.order-higher-indicator::before{color:#fff!important}
        .label{background:#007cba;color:#fff;padding:5px;border-radius:1px; margin-bottom:5px;}
        .inside{border:1px solid #007cba;padding:10px!important;margin:0px!important}
        .trending-flex{display:flex;justify-content:space-between;padding:5px;border:1px solid #ddd;margin-bottom:10px}
        .section-header {display:flex; justify-content:space-between; align-items:center; margin:20px 0 10px; padding-bottom:5px; border-bottom:2px solid #007cba;}
        .section-header h3, .section-header h4 {margin:0;}
        .notice-section, .episode-section {border: 2px solid #007cba; margin: 15px 0; padding: 10px; border-radius: 5px;}
        .button-row, .episode-button-row {background: #f0f0f0;}
        .additional-buttons-section {background: #f5f5f5;}
        .additional-button-row, .episode-additional-button-row, .notice-additional-button-row {background: #e9e9e9; margin: 5px 0; padding: 8px; border-radius: 3px;}
    </style>
    
    <script type="text/javascript">
        jQuery(document).ready(function($) {
            var mediaUploader;
            $('.img-upload-button').click(function(e) {
                e.preventDefault();
                if (mediaUploader) {
                    mediaUploader.open();
                    return;
                }
                mediaUploader = wp.media({
                    title: 'Choose Image',
                    button: { text: 'Select Image' },
                    multiple: false
                });
                mediaUploader.on('select', function() {
                    var attachment = mediaUploader.state().get('selection').first().toJSON();
                    $('#image_file_url').val(attachment.url);
                });
                mediaUploader.open();
            });
            
            // Additional buttons functionality
            var additionalButtonCounters = {1: <?php echo count($additional_buttons_1); ?>, 2: <?php echo count($additional_buttons_2); ?>, 3: <?php echo count($additional_buttons_3); ?>, 4: <?php echo count($additional_buttons_4); ?>, 5: <?php echo count($additional_buttons_5); ?>};
            
            $('.add-additional-button').click(function() {
                var buttonNumber = $(this).data('button');
                var container = $(this).siblings('.additional-buttons-container[data-button="' + buttonNumber + '"]');
                var index = additionalButtonCounters[buttonNumber]++;
                
                var html = '<div class="additional-button-row" data-index="' + index + '">' +
                    '<div class="fields">' +
                    '<div style="margin-bottom: 10px;">' +
                    '<strong style="display: block; margin-bottom: 5px;">Button Text (Required)</strong>' +
                    '<input type="text" name="additional_buttons_' + buttonNumber + '[' + index + '][text]" value="" placeholder="480p, 720p, 1080p, etc." style="width:100%; margin-bottom:5px;"/>' +
                    '</div>' +
                    '<div style="margin-bottom: 10px;">' +
                    '<strong style="display: block; margin-bottom: 5px;">Button URL (Required)</strong>' +
                    '<input type="text" name="additional_buttons_' + buttonNumber + '[' + index + '][url]" value="" placeholder="https://example.com/" style="width:100%; margin-bottom:5px;"/>' +
                    '</div>' +
                    '<button type="button" class="button remove-additional-button" style="background:#dc3232; color:white; margin-bottom:10px;">Remove Button</button>' +
                    '</div>' +
                    '</div>';
                
                container.append(html);
            });
            
            $(document).on('click', '.remove-additional-button', function() {
                $(this).closest('.additional-button-row').remove();
            });
            
            // Episode section functionality
            $('.add-episode-section').click(function() {
                var sectionIndex = $('#episode-sections-container .episode-section').length;
                var html = '<div class="episode-section" data-section-index="' + sectionIndex + '">' +
                    '<div class="row section-header">' +
                    '<div class="label">Episode Section ' + (sectionIndex + 1) + '</div>' +
                    '<button type="button" class="button remove-episode-section" style="background:#dc3232; color:white;">Remove Section</button>' +
                    '</div>' +
                    '<div class="row">' +
                    '<div class="label">Episode Number/Name (Required)</div>' +
                    '<div class="fields">' +
                    '<input type="text" name="episode_sections[' + sectionIndex + '][episode_number]" value="" placeholder="e.g., Episode 1, Episode 2, etc." style="width:100%;"/>' +
                    '<p style="font-size: 12px; color: #666; margin: 5px 0 0 0;"><em>This will be displayed as the episode title in bordered box</em></p>' +
                    '</div>' +
                    '</div>' +
                    '<div class="row">' +
                    '<div class="label">Episode Subtitle (Optional)</div>' +
                    '<div class="fields">' +
                    '<input type="text" name="episode_sections[' + sectionIndex + '][episode_subtitle]" value="" placeholder="e.g., Special Episode, Final Episode, etc." style="width:100%;"/>' +
                    '<p style="font-size: 12px; color: #666; margin: 5px 0 0 0;"><em>This will be displayed below the episode title without border</em></p>' +
                    '</div>' +
                    '</div>' +
                    '<div class="row">' +
                    '<div class="label">Watch Online URL (Optional)</div>' +
                    '<div class="fields">' +
                    '<input type="text" name="episode_sections[' + sectionIndex + '][watch_online_url]" value="" placeholder="https://example.com/watch-episode" style="width:100%;"/>' +
                    '</div>' +
                    '</div>' +
                    '<div class="row">' +
                    '<div class="label">Show "New Added" Badge</div>' +
                    '<div class="fields">' +
                    '<input type="checkbox" name="episode_sections[' + sectionIndex + '][badge]" value="1"/> Show New Added Badge' +
                    '</div>' +
                    '</div>' +
                    '<div class="section-header">' +
                    '<h4>Download Buttons for This Episode</h4>' +
                    '<button type="button" class="button button-primary add-episode-button" data-section="' + sectionIndex + '">Add Button</button>' +
                    '</div>' +
                    '<div class="episode-buttons-container" data-section="' + sectionIndex + '">' +
                    '<div class="row episode-button-row" data-button-index="0">' +
                    
                    // NEW: Button Subtitle
                    '<div class="row">' +
                    '<div class="label">Button Subtitle (Optional)</div>' +
                    '<div class="fields">' +
                    '<input type="text" name="episode_sections[' + sectionIndex + '][buttons][0][button_subtitle]" value="" placeholder="e.g., Special Version, Director\'s Cut, etc." style="width:100%;"/>' +
                    '<p style="font-size: 12px; color: #666; margin: 5px 0 0 0;"><em>This will be displayed above this specific button</em></p>' +
                    '</div>' +
                    '</div>' +
                    
                    // NEW: Button Watch Online URL
                    '<div class="row">' +
                    '<div class="label">Button Watch Online URL (Optional)</div>' +
                    '<div class="fields">' +
                    '<input type="text" name="episode_sections[' + sectionIndex + '][buttons][0][button_watch_online]" value="" placeholder="https://example.com/watch-this-version" style="width:100%;"/>' +
                    '<p style="font-size: 12px; color: #666; margin: 5px 0 0 0;"><em>Watch online URL for this specific button</em></p>' +
                    '</div>' +
                    '</div>' +
                    
                    '<div class="label">Button Text (Required)</div>' +
                    '<div class="fields">' +
                    '<input type="text" name="episode_sections[' + sectionIndex + '][buttons][0][text]" value="" placeholder="480p, 720p, 1080p, etc." style="width:100%; margin-bottom:5px;"/>' +
                    '</div>' +
                    '<div class="label">Button URL (Optional)</div>' +
                    '<div class="fields">' +
                    '<input type="text" name="episode_sections[' + sectionIndex + '][buttons][0][url]" value="" placeholder="https://example.com/" style="width:100%; margin-bottom:5px;"/>' +
                    '<p style="font-size: 12px; color: #666; margin: 5px 0 0 0;"><em>Leave empty to use as toggle for additional buttons</em></p>' +
                    '</div>' +
                    '<div class="label">Additional Buttons for This Button</div>' +
                    '<p style="font-size: 12px; color: #666; margin: 5px 0 10px 0;"><em>These will show when main button has no link</em></p>' +
                    '<button type="button" class="button add-episode-additional-button" data-section="' + sectionIndex + '" data-button="0">Add Additional Button</button>' +
                    '<div class="episode-additional-buttons-container" data-section="' + sectionIndex + '" data-button="0">' +
                    '<div class="episode-additional-button-row" data-index="0">' +
                    '<div class="fields">' +
                    '<div style="margin-bottom: 10px;">' +
                    '<strong style="display: block; margin-bottom: 5px;">Button Text (Required)</strong>' +
                    '<input type="text" name="episode_sections[' + sectionIndex + '][buttons][0][additional_buttons][0][text]" value="" placeholder="480p, 720p, 1080p, etc." style="width:100%; margin-bottom:5px;"/>' +
                    '</div>' +
                    '<div style="margin-bottom: 10px;">' +
                    '<strong style="display: block; margin-bottom: 5px;">Button URL (Required)</strong>' +
                    '<input type="text" name="episode_sections[' + sectionIndex + '][buttons][0][additional_buttons][0][url]" value="" placeholder="https://example.com/" style="width:100%; margin-bottom:5px;"/>' +
                    '</div>' +
                    '<button type="button" class="button remove-episode-additional-button" style="background:#dc3232; color:white; margin-bottom:10px;">Remove Button</button>' +
                    '</div>' +
                    '</div>' +
                    '</div>' +
                    '<button type="button" class="button remove-episode-button" style="background:#dc3232; color:white; margin-top: 10px;">Remove Button</button>' +
                    '</div>' +
                    '</div>' +
                    '</div>';
                
                $('#episode-sections-container').append(html);
            });
            
            // Remove Episode Section
            $(document).on('click', '.remove-episode-section', function() {
                $(this).closest('.episode-section').remove();
                // Reindex sections
                $('#episode-sections-container .episode-section').each(function(i) {
                    $(this).attr('data-section-index', i);
                    $(this).find('.label:first').text('Episode Section ' + (i + 1));
                    $(this).find('input[name*="episode_sections"]').each(function() {
                        var name = $(this).attr('name').replace(/episode_sections\[\d+\]/g, 'episode_sections[' + i + ']');
                        $(this).attr('name', name);
                    });
                    $(this).find('.add-episode-button').attr('data-section', i);
                    $(this).find('.episode-buttons-container').attr('data-section', i);
                    $(this).find('.add-episode-additional-button').each(function() {
                        $(this).attr('data-section', i);
                    });
                    $(this).find('.episode-additional-buttons-container').each(function() {
                        $(this).attr('data-section', i);
                    });
                });
            });
            
            // Add Button to Episode Section
            $(document).on('click', '.add-episode-button', function() {
                var sectionIndex = $(this).data('section');
                var container = $(this).closest('.episode-section').find('.episode-buttons-container');
                var buttonIndex = container.find('.episode-button-row').length;
                
                var html = '<div class="row episode-button-row" data-button-index="' + buttonIndex + '">' +
                    
                    // NEW: Button Subtitle
                    '<div class="row">' +
                    '<div class="label">Button Subtitle (Optional)</div>' +
                    '<div class="fields">' +
                    '<input type="text" name="episode_sections[' + sectionIndex + '][buttons][' + buttonIndex + '][button_subtitle]" value="" placeholder="e.g., Special Version, Director\'s Cut, etc." style="width:100%;"/>' +
                    '<p style="font-size: 12px; color: #666; margin: 5px 0 0 0;"><em>This will be displayed above this specific button</em></p>' +
                    '</div>' +
                    '</div>' +
                    
                    // NEW: Button Watch Online URL
                    '<div class="row">' +
                    '<div class="label">Button Watch Online URL (Optional)</div>' +
                    '<div class="fields">' +
                    '<input type="text" name="episode_sections[' + sectionIndex + '][buttons][' + buttonIndex + '][button_watch_online]" value="" placeholder="https://example.com/watch-this-version" style="width:100%;"/>' +
                    '<p style="font-size: 12px; color: #666; margin: 5px 0 0 0;"><em>Watch online URL for this specific button</em></p>' +
                    '</div>' +
                    '</div>' +
                    
                    '<div class="label">Button Text (Required)</div>' +
                    '<div class="fields">' +
                    '<input type="text" name="episode_sections[' + sectionIndex + '][buttons][' + buttonIndex + '][text]" value="" placeholder="480p, 720p, 1080p, etc." style="width:100%; margin-bottom:5px;"/>' +
                    '</div>' +
                    '<div class="label">Button URL (Optional)</div>' +
                    '<div class="fields">' +
                    '<input type="text" name="episode_sections[' + sectionIndex + '][buttons][' + buttonIndex + '][url]" value="" placeholder="https://example.com/" style="width:100%; margin-bottom:5px;"/>' +
                    '<p style="font-size: 12px; color: #666; margin: 5px 0 0 0;"><em>Leave empty to use as toggle for additional buttons</em></p>' +
                    '</div>' +
                    '<div class="label">Additional Buttons for This Button</div>' +
                    '<p style="font-size: 12px; color: #666; margin: 5px 0 10px 0;"><em>These will show when main button has no link</em></p>' +
                    '<button type="button" class="button add-episode-additional-button" data-section="' + sectionIndex + '" data-button="' + buttonIndex + '">Add Additional Button</button>' +
                    '<div class="episode-additional-buttons-container" data-section="' + sectionIndex + '" data-button="' + buttonIndex + '">' +
                    '<div class="episode-additional-button-row" data-index="0">' +
                    '<div class="fields">' +
                    '<div style="margin-bottom: 10px;">' +
                    '<strong style="display: block; margin-bottom: 5px;">Button Text (Required)</strong>' +
                    '<input type="text" name="episode_sections[' + sectionIndex + '][buttons][' + buttonIndex + '][additional_buttons][0][text]" value="" placeholder="480p, 720p, 1080p, etc." style="width:100%; margin-bottom:5px;"/>' +
                    '</div>' +
                    '<div style="margin-bottom: 10px;">' +
                    '<strong style="display: block; margin-bottom: 5px;">Button URL (Required)</strong>' +
                    '<input type="text" name="episode_sections[' + sectionIndex + '][buttons][' + buttonIndex + '][additional_buttons][0][url]" value="" placeholder="https://example.com/" style="width:100%; margin-bottom:5px;"/>' +
                    '</div>' +
                    '<button type="button" class="button remove-episode-additional-button" style="background:#dc3232; color:white; margin-bottom:10px;">Remove Button</button>' +
                    '</div>' +
                    '</div>' +
                    '</div>' +
                    '<button type="button" class="button remove-episode-button" style="background:#dc3232; color:white; margin-top: 10px;">Remove Button</button>' +
                    '</div>';
                
                container.append(html);
            });
            
            // Remove Button from Episode Section
            $(document).on('click', '.remove-episode-button', function() {
                var buttonRow = $(this).closest('.episode-button-row');
                var container = $(this).closest('.episode-buttons-container');
                
                if (container.find('.episode-button-row').length > 1) {
                    buttonRow.remove();
                    
                    // Reindex buttons in this section
                    var sectionIndex = container.data('section');
                    container.find('.episode-button-row').each(function(i) {
                        $(this).attr('data-button-index', i);
                        $(this).find('input[name*="text"]').attr('name', 'episode_sections[' + sectionIndex + '][buttons][' + i + '][text]');
                        $(this).find('input[name*="url"]').attr('name', 'episode_sections[' + sectionIndex + '][buttons][' + i + '][url]');
                        $(this).find('input[name*="button_subtitle"]').attr('name', 'episode_sections[' + sectionIndex + '][buttons][' + i + '][button_subtitle]');
                        $(this).find('input[name*="button_watch_online"]').attr('name', 'episode_sections[' + sectionIndex + '][buttons][' + i + '][button_watch_online]');
                        $(this).find('.add-episode-additional-button').attr('data-button', i);
                        $(this).find('.episode-additional-buttons-container').attr('data-button', i);
                        $(this).find('.episode-additional-button-row input').each(function() {
                            var name = $(this).attr('name').replace(/buttons\]\[\d+\]\[additional_buttons\]/, 'buttons][' + i + '][additional_buttons]');
                            $(this).attr('name', name);
                        });
                    });
                } else {
                    alert('Each episode section needs at least one button.');
                }
            });
            
            // Episode section additional buttons
            $(document).on('click', '.add-episode-additional-button', function() {
                var sectionIndex = $(this).data('section');
                var buttonIndex = $(this).data('button');
                var container = $(this).siblings('.episode-additional-buttons-container[data-section="' + sectionIndex + '"][data-button="' + buttonIndex + '"]');
                var currentCount = container.find('.episode-additional-button-row').length;
                
                var html = '<div class="episode-additional-button-row" data-index="' + currentCount + '">' +
                    '<div class="fields">' +
                    '<div style="margin-bottom: 10px;">' +
                    '<strong style="display: block; margin-bottom: 5px;">Button Text (Required)</strong>' +
                    '<input type="text" name="episode_sections[' + sectionIndex + '][buttons][' + buttonIndex + '][additional_buttons][' + currentCount + '][text]" value="" placeholder="480p, 720p, 1080p, etc." style="width:100%; margin-bottom:5px;"/>' +
                    '</div>' +
                    '<div style="margin-bottom: 10px;">' +
                    '<strong style="display: block; margin-bottom: 5px;">Button URL (Required)</strong>' +
                    '<input type="text" name="episode_sections[' + sectionIndex + '][buttons][' + buttonIndex + '][additional_buttons][' + currentCount + '][url]" value="" placeholder="https://example.com/" style="width:100%; margin-bottom:5px;"/>' +
                    '</div>' +
                    '<button type="button" class="button remove-episode-additional-button" style="background:#dc3232; color:white; margin-bottom:10px;">Remove Button</button>' +
                    '</div>' +
                    '</div>';
                
                container.append(html);
            });
            
            $(document).on('click', '.remove-episode-additional-button', function() {
                $(this).closest('.episode-additional-button-row').remove();
            });
            
            // Existing notice section functions
            $('.add-notice-section').click(function() {
                var sectionIndex = $('#notice-sections-container .notice-section').length;
                var html = '<div class="notice-section" data-section-index="' + sectionIndex + '">' +
                    '<div class="row section-header">' +
                    '<div class="label">Notice Section ' + (sectionIndex + 1) + '</div>' +
                    '<button type="button" class="button remove-notice-section" style="background:#dc3232; color:white;">Remove Section</button>' +
                    '</div>' +
                    '<div class="row">' +
                    '<div class="label">Section Title</div>' +
                    '<div class="fields">' +
                    '<input type="text" name="notice_sections[' + sectionIndex + '][notice]" value="" placeholder="e.g., Hindi Dubbed, Bangla Dubbed" style="width:100%;"/>' +
                    '</div>' +
                    '</div>' +
                    '<div class="section-header">' +
                    '<h4>Download Buttons for This Section</h4>' +
                    '<button type="button" class="button button-primary add-section-button" data-section="' + sectionIndex + '">Add Button</button>' +
                    '</div>' +
                    '<div class="section-buttons-container" data-section="' + sectionIndex + '">' +
                    '<div class="row button-row" data-button-index="0">' +
                    '<div class="label">Button Text (Required)</div>' +
                    '<div class="fields">' +
                    '<input type="text" name="notice_sections[' + sectionIndex + '][buttons][0][text]" value="" placeholder="480p, 720p, 1080p, etc." style="width:100%; margin-bottom:5px;"/>' +
                    '</div>' +
                    '<div class="label">Button URL (Optional)</div>' +
                    '<div class="fields">' +
                    '<input type="text" name="notice_sections[' + sectionIndex + '][buttons][0][url]" value="" placeholder="https://example.com/" style="width:100%; margin-bottom:5px;"/>' +
                    '<p style="font-size: 12px; color: #666; margin: 5px 0 0 0;"><em>Leave empty to use as toggle for additional buttons</em></p>' +
                    '</div>' +
                    '<div class="label">Additional Buttons for This Button</div>' +
                    '<p style="font-size: 12px; color: #666; margin: 5px 0 10px 0;"><em>These will show when main button has no link</em></p>' +
                    '<button type="button" class="button add-notice-additional-button" data-section="' + sectionIndex + '" data-button="0">Add Additional Button</button>' +
                    '<div class="notice-additional-buttons-container" data-section="' + sectionIndex + '" data-button="0">' +
                    '<div class="notice-additional-button-row" data-index="0">' +
                    '<div class="fields">' +
                    '<div style="margin-bottom: 10px;">' +
                    '<strong style="display: block; margin-bottom: 5px;">Button Text (Required)</strong>' +
                    '<input type="text" name="notice_sections[' + sectionIndex + '][buttons][0][additional_buttons][0][text]" value="" placeholder="480p, 720p, 1080p, etc." style="width:100%; margin-bottom:5px;"/>' +
                    '</div>' +
                    '<div style="margin-bottom: 10px;">' +
                    '<strong style="display: block; margin-bottom: 5px;">Button URL (Required)</strong>' +
                    '<input type="text" name="notice_sections[' + sectionIndex + '][buttons][0][additional_buttons][0][url]" value="" placeholder="https://example.com/" style="width:100%; margin-bottom:5px;"/>' +
                    '</div>' +
                    '<button type="button" class="button remove-notice-additional-button" style="background:#dc3232; color:white; margin-bottom:10px;">Remove Button</button>' +
                    '</div>' +
                    '</div>' +
                    '</div>' +
                    '<button type="button" class="button remove-section-button" style="background:#dc3232; color:white; margin-top: 10px;">Remove Button</button>' +
                    '</div>' +
                    '</div>' +
                    '</div>';
                
                $('#notice-sections-container').append(html);
            });
            
            // Remove Notice Section
            $(document).on('click', '.remove-notice-section', function() {
                $(this).closest('.notice-section').remove();
                // Reindex sections
                $('#notice-sections-container .notice-section').each(function(i) {
                    $(this).attr('data-section-index', i);
                    $(this).find('.label:first').text('Notice Section ' + (i + 1));
                    $(this).find('input[name*="notice_sections"]').each(function() {
                        var name = $(this).attr('name').replace(/notice_sections\[\d+\]/g, 'notice_sections[' + i + ']');
                        $(this).attr('name', name);
                    });
                    $(this).find('.add-section-button').attr('data-section', i);
                    $(this).find('.section-buttons-container').attr('data-section', i);
                    $(this).find('.add-notice-additional-button').each(function() {
                        $(this).attr('data-section', i);
                    });
                    $(this).find('.notice-additional-buttons-container').each(function() {
                        $(this).attr('data-section', i);
                    });
                });
            });
            
            // Add Button to Section
            $(document).on('click', '.add-section-button', function() {
                var sectionIndex = $(this).data('section');
                var container = $(this).closest('.notice-section').find('.section-buttons-container');
                var buttonIndex = container.find('.button-row').length;
                
                var html = '<div class="row button-row" data-button-index="' + buttonIndex + '">' +
                    '<div class="label">Button Text (Required)</div>' +
                    '<div class="fields">' +
                    '<input type="text" name="notice_sections[' + sectionIndex + '][buttons][' + buttonIndex + '][text]" value="" placeholder="480p, 720p, 1080p, etc." style="width:100%; margin-bottom:5px;"/>' +
                    '</div>' +
                    '<div class="label">Button URL (Optional)</div>' +
                    '<div class="fields">' +
                    '<input type="text" name="notice_sections[' + sectionIndex + '][buttons][' + buttonIndex + '][url]" value="" placeholder="https://example.com/" style="width:100%; margin-bottom:5px;"/>' +
                    '<p style="font-size: 12px; color: #666; margin: 5px 0 0 0;"><em>Leave empty to use as toggle for additional buttons</em></p>' +
                    '</div>' +
                    '<div class="label">Additional Buttons for This Button</div>' +
                    '<p style="font-size: 12px; color: #666; margin: 5px 0 10px 0;"><em>These will show when main button has no link</em></p>' +
                    '<button type="button" class="button add-notice-additional-button" data-section="' + sectionIndex + '" data-button="' + buttonIndex + '">Add Additional Button</button>' +
                    '<div class="notice-additional-buttons-container" data-section="' + sectionIndex + '" data-button="' + buttonIndex + '">' +
                    '<div class="notice-additional-button-row" data-index="0">' +
                    '<div class="fields">' +
                    '<div style="margin-bottom: 10px;">' +
                    '<strong style="display: block; margin-bottom: 5px;">Button Text (Required)</strong>' +
                    '<input type="text" name="notice_sections[' + sectionIndex + '][buttons][' + buttonIndex + '][additional_buttons][0][text]" value="" placeholder="480p, 720p, 1080p, etc." style="width:100%; margin-bottom:5px;"/>' +
                    '</div>' +
                    '<div style="margin-bottom: 10px;">' +
                    '<strong style="display: block; margin-bottom: 5px;">Button URL (Required)</strong>' +
                    '<input type="text" name="notice_sections[' + sectionIndex + '][buttons][' + buttonIndex + '][additional_buttons][0][url]" value="" placeholder="https://example.com/" style="width:100%; margin-bottom:5px;"/>' +
                    '</div>' +
                    '<button type="button" class="button remove-notice-additional-button" style="background:#dc3232; color:white; margin-bottom:10px;">Remove Button</button>' +
                    '</div>' +
                    '</div>' +
                    '</div>' +
                    '<button type="button" class="button remove-section-button" style="background:#dc3232; color:white; margin-top: 10px;">Remove Button</button>' +
                    '</div>';
                
                container.append(html);
            });
            
            // Remove Button from Section
            $(document).on('click', '.remove-section-button', function() {
                var buttonRow = $(this).closest('.button-row');
                var container = $(this).closest('.section-buttons-container');
                
                if (container.find('.button-row').length > 1) {
                    buttonRow.remove();
                    
                    // Reindex buttons in this section
                    var sectionIndex = container.data('section');
                    container.find('.button-row').each(function(i) {
                        $(this).attr('data-button-index', i);
                        $(this).find('input[name*="text"]').attr('name', 'notice_sections[' + sectionIndex + '][buttons][' + i + '][text]');
                        $(this).find('input[name*="url"]').attr('name', 'notice_sections[' + sectionIndex + '][buttons][' + i + '][url]');
                        $(this).find('.add-notice-additional-button').attr('data-button', i);
                        $(this).find('.notice-additional-buttons-container').attr('data-button', i);
                        $(this).find('.notice-additional-button-row input').each(function() {
                            var name = $(this).attr('name').replace(/buttons\]\[\d+\]\[additional_buttons\]/, 'buttons][' + i + '][additional_buttons]');
                            $(this).attr('name', name);
                        });
                    });
                } else {
                    alert('Each section needs at least one button.');
                }
            });
            
            // Notice section additional buttons
            $(document).on('click', '.add-notice-additional-button', function() {
                var sectionIndex = $(this).data('section');
                var buttonIndex = $(this).data('button');
                var container = $(this).siblings('.notice-additional-buttons-container[data-section="' + sectionIndex + '"][data-button="' + buttonIndex + '"]');
                var currentCount = container.find('.notice-additional-button-row').length;
                
                var html = '<div class="notice-additional-button-row" data-index="' + currentCount + '">' +
                    '<div class="fields">' +
                    '<div style="margin-bottom: 10px;">' +
                    '<strong style="display: block; margin-bottom: 5px;">Button Text (Required)</strong>' +
                    '<input type="text" name="notice_sections[' + sectionIndex + '][buttons][' + buttonIndex + '][additional_buttons][' + currentCount + '][text]" value="" placeholder="480p, 720p, 1080p, etc." style="width:100%; margin-bottom:5px;"/>' +
                    '</div>' +
                    '<div style="margin-bottom: 10px;">' +
                    '<strong style="display: block; margin-bottom: 5px;">Button URL (Required)</strong>' +
                    '<input type="text" name="notice_sections[' + sectionIndex + '][buttons][' + buttonIndex + '][additional_buttons][' + currentCount + '][url]" value="" placeholder="https://example.com/" style="width:100%; margin-bottom:5px;"/>' +
                    '</div>' +
                    '<button type="button" class="button remove-notice-additional-button" style="background:#dc3232; color:white; margin-bottom:10px;">Remove Button</button>' +
                    '</div>' +
                    '</div>';
                
                container.append(html);
            });
            
            $(document).on('click', '.remove-notice-additional-button', function() {
                $(this).closest('.notice-additional-button-row').remove();
            });
        });
    </script>
    <?php
}

function movielinkbd_save_metaboxes($post_id){
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    if (!current_user_can('edit_post', $post_id)) return;
    
    // Save traditional fields
    $fields = [
        'image_file_url' => 'custom-field-1',
        'custom-field-2' => 'custom-field-2',
        'custom-field-3' => 'custom-field-3',
        'custom-field-4' => 'custom-field-4',
        'custom-field-6' => 'custom-field-6',
        'custom-field-7' => 'custom-field-7',
        'custom-field-8' => 'custom-field-8',
        'custom-field-9' => 'custom-field-9',
        'custom-field-10' => 'custom-field-10',
        'custom-field-11' => 'custom-field-11',
        'custom-field-12' => 'custom-field-12',
        'custom-field-13' => 'custom-field-13',
        'custom-field-34' => 'custom-field-34',
        'trending' => 'custom-field-5',
        'watch_online_url' => 'watch_online_url',
        'is_episode' => 'is_episode',
        'episode_range' => 'episode_range',
        'pinned_badge' => 'pinned_badge',
        'new_badge' => 'new_badge',
        'yes_no_toggle' => 'yes_no_toggle',
        'adult_yes_no_toggle' => 'adult_yes_no_toggle'
    ];

    foreach ($fields as $field => $meta_key) {
        if (isset($_POST[$field])) {
            update_post_meta($post_id, $meta_key, sanitize_text_field($_POST[$field]));
        } else {
            // For checkboxes, if not set, set to empty
            if ($field === 'is_episode' || $field === 'pinned_badge' || $field === 'new_badge' || $field === 'yes_no_toggle' || $field === 'adult_yes_no_toggle') {
                update_post_meta($post_id, $meta_key, '');
            }
        }
    }
    
    // Save additional buttons for main buttons
    for ($i = 1; $i <= 5; $i++) {
        $additional_buttons_key = 'additional_buttons_' . $i;
        if (isset($_POST[$additional_buttons_key])) {
            $additional_buttons = array();
            foreach ($_POST[$additional_buttons_key] as $button_data) {
                if (!empty($button_data['text']) && !empty($button_data['url'])) {
                    $additional_buttons[] = array(
                        'text' => sanitize_text_field($button_data['text']),
                        'url' => esc_url_raw($button_data['url'])
                    );
                }
            }
            update_post_meta($post_id, $additional_buttons_key, $additional_buttons);
        } else {
            delete_post_meta($post_id, $additional_buttons_key);
        }
    }
    
    // Save episode sections
    if (isset($_POST['episode_sections'])) {
        $episode_sections = array();
        
        foreach ($_POST['episode_sections'] as $section_index => $section_data) {
            $episode_number = isset($section_data['episode_number']) ? sanitize_text_field($section_data['episode_number']) : '';
            $episode_subtitle = isset($section_data['episode_subtitle']) ? sanitize_text_field($section_data['episode_subtitle']) : '';
            $watch_online_url = isset($section_data['watch_online_url']) ? esc_url_raw($section_data['watch_online_url']) : '';
            $badge = isset($section_data['badge']) ? sanitize_text_field($section_data['badge']) : '';
            
            $buttons = array();
            if (isset($section_data['buttons'])) {
                foreach ($section_data['buttons'] as $button_index => $button_data) {
                    $button_subtitle = isset($button_data['button_subtitle']) ? sanitize_text_field($button_data['button_subtitle']) : '';
                    $button_watch_online = isset($button_data['button_watch_online']) ? esc_url_raw($button_data['button_watch_online']) : '';
                    $text = isset($button_data['text']) ? sanitize_text_field($button_data['text']) : '';
                    $url = isset($button_data['url']) ? esc_url_raw($button_data['url']) : '';
                    
                    $additional_buttons = array();
                    if (isset($button_data['additional_buttons'])) {
                        foreach ($button_data['additional_buttons'] as $add_index => $add_button_data) {
                            $add_text = isset($add_button_data['text']) ? sanitize_text_field($add_button_data['text']) : '';
                            $add_url = isset($add_button_data['url']) ? esc_url_raw($add_button_data['url']) : '';
                            
                            if (!empty($add_text) && !empty($add_url)) {
                                $additional_buttons[] = array(
                                    'text' => $add_text,
                                    'url' => $add_url
                                );
                            }
                        }
                    }
                    
                    if (!empty($text)) {
                        $buttons[] = array(
                            'button_subtitle' => $button_subtitle,
                            'button_watch_online' => $button_watch_online,
                            'text' => $text,
                            'url' => $url,
                            'additional_buttons' => $additional_buttons
                        );
                    }
                }
            }
            
            if (!empty($episode_number) || !empty($episode_subtitle) || !empty($watch_online_url) || !empty($buttons)) {
                $episode_sections[] = array(
                    'episode_number' => $episode_number,
                    'episode_subtitle' => $episode_subtitle,
                    'watch_online_url' => $watch_online_url,
                    'badge' => $badge,
                    'buttons' => $buttons
                );
            }
        }
        
        update_post_meta($post_id, '_episode_sections', $episode_sections);
    } else {
        delete_post_meta($post_id, '_episode_sections');
    }
    
    // Save notice sections with additional buttons
    if (isset($_POST['notice_sections'])) {
        $notice_sections = array();
        
        foreach ($_POST['notice_sections'] as $section_index => $section_data) {
            $notice = isset($section_data['notice']) ? sanitize_text_field($section_data['notice']) : '';
            
            $buttons = array();
            if (isset($section_data['buttons'])) {
                foreach ($section_data['buttons'] as $button_index => $button_data) {
                    $text = isset($button_data['text']) ? sanitize_text_field($button_data['text']) : '';
                    $url = isset($button_data['url']) ? esc_url_raw($button_data['url']) : '';
                    
                    $additional_buttons = array();
                    if (isset($button_data['additional_buttons'])) {
                        foreach ($button_data['additional_buttons'] as $add_index => $add_button_data) {
                            $add_text = isset($add_button_data['text']) ? sanitize_text_field($add_button_data['text']) : '';
                            $add_url = isset($add_button_data['url']) ? esc_url_raw($add_button_data['url']) : '';
                            
                            if (!empty($add_text) && !empty($add_url)) {
                                $additional_buttons[] = array(
                                    'text' => $add_text,
                                    'url' => $add_url
                                );
                            }
                        }
                    }
                    
                    if (!empty($text)) {
                        $buttons[] = array(
                            'text' => $text,
                            'url' => $url,
                            'additional_buttons' => $additional_buttons
                        );
                    }
                }
            }
            
            if (!empty($notice) || !empty($buttons)) {
                $notice_sections[] = array(
                    'notice' => $notice,
                    'buttons' => $buttons
                );
            }
        }
        
        update_post_meta($post_id, '_notice_sections', $notice_sections);
    } else {
        delete_post_meta($post_id, '_notice_sections');
    }
}
add_action('save_post', 'movielinkbd_save_metaboxes');