<?php
/**
 * MovieLinkBD header and definitions
 *
 * @package MovieLinkBD.Com
 * Author: 9xfreak.com
 * @since MovieLinkBD 1.0
 */
global $movielinkbd;
?>
<html <?php language_attributes(); ?> lang="en">
	<head>
	    <!-- Google Tag Manager - Optimized -->
	    <script>
	    (function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
	    new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
	    j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
	    'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
	    })(window,document,'script','dataLayer','GTM-TCCSDF99');
	    </script>
	    
		<meta charset="<?php bloginfo( 'charset' ); ?>">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		
		<!-- SEO Meta Tags -->
		<title>aamovies.com | aamovies | Watch & Download Movies, Web Series, and Anime – All Genres, All Languages</title>
		<meta name="description" content="Watch and download movies, web series, and anime in all languages and genres. Stream in HD quality on aamovies.">
		
		<!-- Core Meta Tags -->
		<meta name="robots" content="index, follow">
		<meta name="theme-color" content="#031621">
		<meta name="language" content="en">
		
		<!-- Preload Critical Resources -->
		<link rel="preconnect" href="https://fonts.googleapis.com">
		<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
		<link rel="preconnect" href="https://cdnjs.cloudflare.com" crossorigin>

		<!-- Inline Critical CSS with !important -->
		<style>
			/*! Critical above-the-fold styles */
			body { margin: 0 !important; padding: 0 !important; }
			.header-text-section { 
				color: #ffffff !important; 
				font-family: 'Inter', Arial, sans-serif !important; 
				font-size: 11px !important; 
				line-height: 1.3 !important; 
				text-align: center !important; 
				padding: 8px 5px !important; 
				background: transparent !important; 
				margin: 0 !important;
			}
			.header-text-section .green-text { color: #16a34a !important; }
			.header-text-section .orange-text { color: #d97706 !important; }
			.header-text-section .blue-text { color: #2563eb !important; }
			.header-text-section .purple-text { color: #c026d3 !important; }
			.header-text-section .red-text { color: #dc2626 !important; }
			.header-text-section .yellow-text { color: #ca8a04 !important; }
			.header-text-section .sky-blue-text { color: #87CEEB !important; }
			.header-text-section i.fas { color: inherit !important; }
		</style>

		<!-- Deferred Non-Critical CSS -->
		<link rel="preload" href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i&display=swap" as="style" onload="this.onload=null;this.rel='stylesheet'">
		<link rel="preload" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css" as="style" onload="this.onload=null;this.rel='stylesheet'">
		<link rel="preload" href="<?php echo get_template_directory_uri(); ?>/style.css" as="style" onload="this.onload=null;this.rel='stylesheet'">

		<!-- Favicon -->
		<link rel="icon" href="<?php if($movielinkbd['favicon']['url']>0){echo $movielinkbd['favicon']['url'];}else{echo get_template_directory_uri().'/images/favicon/favicon.ico';}?>" type="image/x-icon">
		
		<?php wp_head(); ?>
	</head>
    <body itemtype="https://schema.org/WebPage" itemscope="" style="margin: 0; padding: 0;">
        <!-- Google Tag Manager (noscript) -->
        <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-TCCSDF99" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
        
        <!-- ===== REFERENCE-STYLE HEADER (replaces original logo div) ===== -->
        <div id="max-wrap">
            <header class="header-pc">
                <div class="header">
                    <!-- Hamburger Menu Icon (3-dot menu) -->
                    <a onclick="myMenubar()" align="left" href="javascript:void(0);" class="icon">
                        <i id="togglemenubar" class="fa fa-bars"></i>
                    </a>

                    <!-- Site Logo (single, not duplicate) -->
                    <a href="<?php echo home_url(); ?>" class="navbar-brand">
                        <img width="<?php echo $movielinkbd['width']; ?>" height="<?php echo $movielinkbd['height']; ?>" src="<?php if($movielinkbd['logo']['url']>0){echo $movielinkbd['logo']['url'];}else{echo get_template_directory_uri().'/images/logo.png';}?>" alt="<?php echo $movielinkbd['alt']; ?>" style="max-height: 40px; width: auto; display: block;"/>
                    </a>

                    <!-- Search Icon -->
                    <a align="right" href="javascript:void(0);" class="icon right" onclick="mySearchBox()">
                        <i class="fa fa-search"></i>
                    </a>
                </div>

                <!-- Navigation Menu with Dropdowns (3-dot menu content) -->
                <ul class="topnav" id="myTopnav">
                    <?php
                    // Movies dropdown
                    echo '<li><a class="menubar" href="javascript:void(0)"><i class="fa fa-film" style="color: #f31313;"></i> Movies</a>';
                    echo '<ul class="sub-menu">';
                    $movie_cats = get_categories(array('taxonomy' => 'category', 'hide_empty' => 0, 'number' => 12, 'orderby' => 'name', 'order' => 'ASC'));
                    foreach ($movie_cats as $mc) {
                        echo '<li><a class="submenubar" href="' . get_term_link($mc) . '">' . $mc->name . '</a></li>';
                    }
                    echo '</ul><div style="clear:both"></div></li>';

                    // TV Shows dropdown
                    echo '<li><a class="menubar" href="javascript:void(0)"><i class="fa fa-tv" style="color:#f31313;"></i> TV Shows</a>';
                    echo '<ul class="sub-menu">';
                    echo '<li><a class="submenubar" href="' . home_url('/category/tv-shows/') . '">TV Shows</a></li>';
                    echo '<li><a class="submenubar" href="' . home_url('/category/web-series/') . '">Web Series</a></li>';
                    echo '<li><a class="submenubar" href="' . home_url('/category/ongoing/') . '">Ongoing</a></li>';
                    echo '</ul><div style="clear:both"></div></li>';

                    // Categories dropdown (ALL categories)
                    echo '<li><a class="menubar" href="javascript:void(0)"><i class="fa fa-folder-open" style="color: #f31313;"></i> Categories</a>';
                    echo '<ul class="sub-menu">';
                    $all_cats = get_categories(array('taxonomy' => 'category', 'hide_empty' => 0, 'number' => 21, 'orderby' => 'name', 'order' => 'ASC'));
                    foreach ($all_cats as $ac) {
                        echo '<li><a class="submenubar" href="' . get_term_link($ac) . '">' . $ac->name . '</a></li>';
                    }
                    echo '</ul><div style="clear:both"></div></li>';

                    // Home link
                    echo '<li><a href="' . home_url() . '"><i class="fa-solid fa-house" style="color:#f31313;"></i> Home</a></li>';
                    ?>
                </ul>

                <!-- Search Box (reference style, toggled by search icon) -->
                <div id="searchbox" class="searchbox">
                    <form method="get" class="form-resp-pc" action="<?php echo get_home_url(); ?>">
                        <input type="text" placeholder="Search..." name="s" id="ms" value="" autocomplete="off">
                        <button type="submit" class="search-button">
                            <span class="fa fa-search"></span>
                        </button>
                    </form>
                </div>
            </header>
        </div>

        <!-- JS for hamburger menu and search toggle -->
        <script>
        function myMenubar() {
            var x = document.getElementById("myTopnav");
            if (x.className === "topnav") { x.className += " responsive"; } else { x.className = "topnav"; }
        }
        function mySearchBox() {
            var x = document.getElementById("searchbox");
            if (x.style.display === "block") { x.style.display = "none"; } else { x.style.display = "block"; }
        }
        </script>

        <!-- Reference Header CSS -->
        <style>
        #max-wrap { background-color: #0e0f14; box-shadow: 0 1px 5px rgba(0,0,0,.4); border-bottom: 1px solid #000; padding: 10px 0; }
        .header-pc { max-width:100%; display:grid; grid-template-columns:max-content auto auto; margin:0 auto; padding:0 70px; justify-content:space-between; align-items:center; gap:15px; }
        .header { display:grid; grid-template-columns:auto auto auto; align-items:center; }
        .header .icon { padding:5px; color:#fff; text-decoration:none; font-size:20px; }
        .navbar-brand { display:inline-flex; align-items:center; text-decoration:none; }
        .topnav { position:relative; overflow:visible; background-color:#0e0f14; display:flex; align-items:center; padding:0; list-style:none; margin:0; }
        .topnav li { list-style:none; position:relative; }
        .topnav a { float:left; display:flex; color:#f2f2f2; text-align:center; padding:25px 10px 22px; text-decoration:none; font-size:17px; white-space:nowrap; gap:5px; align-items:center; }
        .topnav a.menubar:after { content:"\f0dd"; font:normal normal normal 14px/1 FontAwesome; font-weight:900; margin-left:5px; font-size:14px; }
        .topnav a:hover { background-color:#ff0000; border-radius:5px; }
        .topnav ul.sub-menu { display:none; position:absolute; left:0; right:0; top:65px; max-width:500px; padding:15px 10px; border-top:solid #ff0a80; background:rgba(0,0,0,.98); box-shadow:0 5px 10px 0 rgba(0,0,0,.2); opacity:.97; z-index:1; border-radius:0 0 10px 10px; list-style:none; }
        .topnav ul.sub-menu li { width:calc(100% / 3); float:left; list-style:none; }
        .topnav ul.sub-menu li a { padding:8px 10px; font-size:14px; }
        .menubar:hover + ul.sub-menu, ul.sub-menu:hover { display:block; }
        .searchbox { display:none; background:#0e0f14; }
        .searchbox form { background:rgba(255,255,255,.1); display:flex; align-items:center; justify-content:space-between; border-radius:5px; margin:0; }
        .searchbox input { background:transparent; color:#fff; padding:10px; border:none; outline:none; width:100%; font-size:15px; }
        .searchbox button { background:transparent; color:#fff; border:none; outline:none; padding:10px; cursor:pointer; }
        @media only screen and (min-width:1319px) { .searchbox { display:block; } }
        @media only screen and (min-width:769px) { .header-pc { grid-template-columns:max-content auto auto !important; } }
        @media screen and (max-width:768px) {
            .topnav a { display:none; }
            .header { display:grid; grid-template-columns:auto auto auto; align-items:center; margin:0 20px; }
            .header a.icon { display:block; padding:5px; }
            .header a.right { float:right; }
            .searchbox { background:#000; position:absolute; left:0; right:0; top:80px; z-index:3; }
            .sub-menu { background:#000; display:grid; grid-template-columns:50% 50%; }
            .topnav.responsive { position:relative; z-index:2; }
            .topnav.responsive .icon { position:absolute; right:0; top:0; }
            .topnav.responsive a { float:none; display:block; text-align:left; padding:10px; border-bottom:1px solid rgba(170,170,170,.4); }
            .menubar { background:rgba(255,0,0,.5); padding:10px !important; }
        }
        /* DLM Box matching reference */
        .dlm-box { display:flex; flex-wrap:wrap; gap:2px; justify-content:center; padding:10px 15px; background:#0e0f14; }
        .dlm-box strong { display:inline-block; }
        .dlm-box strong a { display:inline-block; padding:6px 14px; color:#fff !important; font-size:13px; font-weight:600; text-decoration:none; }
        .dlm-box strong a:hover { opacity:0.8; }
        </style>

        <!-- Original Text Section (PRESERVED EXACTLY) -->
        <div style="background: transparent; margin: 0; padding: 0;">

            <!-- Text Section - Proper Colors with !important -->
            <div class="header-text-section" style="font-family:'Inter', Arial, sans-serif; font-size: 11px; line-height: 1.3; text-align: center; padding: 8px 5px; background: transparent; margin: 0;">
              <div style="margin-bottom: 3px;">
                <span class="green-text" style="font-weight: 600 !important;">
                  <i class="fas fa-check-circle"></i> Official & Always Active Link:
                </span> 
                <span class="orange-text" style="font-weight: 600 !important;">AAMOVIES.COM</span>
              </div>

              <div style="margin-bottom: 3px; color: #ffffff !important;">
                Our backup site is <span class="sky-blue-text" style="font-weight: 600 !important;">FILMCITY.SHOP</span> and our
                <span class="red-text" style="font-weight: 600 !important;">18+ WEBSITE</span> is <span class="red-text" style="font-weight: 600 !important;">9XFREAK.XYZ</span>
              </div>

              <div style="margin-bottom: 8px; color: #ffffff !important;">
                <i class="fas fa-exclamation-triangle yellow-text"></i> If the site doesn't load, use 
                <span class="sky-blue-text" style="font-weight: 600 !important;">1.1.1.1 VPN</span>
              </div>

              <div>
                <a href="https://aamovies.com" style="text-decoration: none; margin: 1px; display: inline-block;">
                  <div style="background: #16a34a !important; color: #fff !important; padding: 3px 8px; border-radius: 3px; font-weight: 600 !important; font-size: 9px; display: inline-block;">
                    <i class="fas fa-external-link-alt"></i> AAMOVIES.COM
                  </div>
                </a>

                <a href="https://filmcity.shop" style="text-decoration: none; margin: 1px; display: inline-block;">
                  <div style="background: #2563eb !important; color: #fff !important; padding: 3px 8px; border-radius: 3px; font-weight: 600 !important; font-size: 9px; display: inline-block;">
                    <i class="fas fa-external-link-alt"></i> FILMCITY.SHOP
                  </div>
                </a>

                <a href="https://9xfreak.xyz" style="text-decoration: none; margin: 1px; display: inline-block;">
                  <div style="background: linear-gradient(to right, #dc2626, #7e22ce) !important; color: #fff !important; padding: 3px 8px; border-radius: 3px; font-weight: 600 !important; font-size: 9px; display: inline-block;">
                    <i class="fas fa-ban"></i> 9XFREAK.XYZ
                  </div>
                </a>
              </div>
            </div>
        </div>

        <?php get_template_part('/templates/parts/header-categories');?>
        <?php get_template_part('/templates/parts/header-searchbox');?>

        <!-- Deferred JavaScript -->
        <script>
        // Load jQuery after page is interactive
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', loadNonCriticalResources);
        } else {
            loadNonCriticalResources();
        }
        
        function loadNonCriticalResources() {
            // Load external script with delay
            setTimeout(function() {
                var script = document.createElement('script');
                script.src = '//sunkendifferextreme.com/e2/5b/7a/e25b7a7d319c7998d0efd502126b96d1.js';
                script.async = true;
                document.body.appendChild(script);
            }, 2000);
        }
        </script>