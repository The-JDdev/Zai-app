document.addEventListener('DOMContentLoaded', function () {
    const container = document.getElementById('auto-swipe-container');
    let index = 0;

    function scrollToNext() {
        const items = container.querySelectorAll('.file-item');
        if (items.length === 0) return;
        index = (index + 1) % items.length;
        container.scrollTo({
            left: items[index].offsetLeft,
            behavior: 'smooth'
        });
    }

    // Set the interval for auto swipe (e.g., every 2 seconds)
    setInterval(scrollToNext, 2000);
});