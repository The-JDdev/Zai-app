// When the user scrolls down 20px from the top of the document, show the button
window.onscroll = function() {scrollFunction()};

function scrollFunction() {
    var pos = window.pageYOffset;
    if (pos > 20 ) {
        document.getElementById('myBtnTop').style.display = 'block';
    } else {
        document.getElementById('myBtnTop').style.display = 'none';
    }
    }
function TopFunction() {
    window.scrollTo({top:0,behavior:'smooth'});
 }